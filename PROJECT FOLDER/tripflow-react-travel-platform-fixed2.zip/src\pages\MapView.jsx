import React, { useRef, useState } from 'react';
import { useTripContext } from '../context/TripContext';
import { Link, useNavigate } from 'react-router-dom';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import { Share2, Download, Save, Plane, Map, ArrowRight, Brain } from 'lucide-react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

// Fix leaflet default icon
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1/dist/images/marker-shadow.png',
});

const createColoredIcon = (color, label) => L.divIcon({
  className: '',
  html: `<div style="width:28px;height:28px;border-radius:50%;background:${color};border:3px solid white;display:flex;align-items:center;justify-content:center;color:white;font-size:11px;font-weight:bold;box-shadow:0 2px 8px rgba(0,0,0,0.5)">${label}</div>`,
  iconSize: [28, 28],
  iconAnchor: [14, 14],
  popupAnchor: [0, -14],
});

const MapBounds = ({ cities }) => {
  const map = useMap();
  React.useEffect(() => {
    if (cities.length > 0) {
      const bounds = L.latLngBounds(cities.map(c => [c.lat, c.lon]));
      if (cities.length === 1) {
        map.setView([cities[0].lat, cities[0].lon], 8);
      } else {
        map.fitBounds(bounds, { padding: [40, 40] });
      }
    }
  }, [cities, map]);
  return null;
};

const TRANSPORT_EMOJI = { Flight: '✈️', Train: '🚆', Bus: '🚌', Drive: '🚗', Ferry: '⛴️' };

const safePdfText = (value, fallback = '-') => {
  const text = String(value ?? '').replace(/[^\x20-\x7E]/g, '').replace(/\s+/g, ' ').trim();
  return text || fallback;
};

const formatDateRange = (city) => {
  if (!city.arrival && !city.departure) return `${city.nights || 0} nights`;
  return `${city.arrival || '?'} to ${city.departure || '?'} | ${city.nights || 0} nights`;
};

const makeFileName = (title) => {
  const cleaned = safePdfText(title, 'TripFlow_Itinerary').replace(/[^a-z0-9_-]+/gi, '_').replace(/^_+|_+$/g, '');
  return `${cleaned || 'TripFlow_Itinerary'}_TripFlow.pdf`;
};

export default function MapView() {
  const { tripCities, currentItinerary, generateItinerary, saveCurrentTrip } = useTripContext();
  const navigate = useNavigate();
  const timelineRef = useRef();
  const [exporting, setExporting] = useState(false);

  const cities = tripCities.filter(c => c.lat && c.lon);
  const positions = cities.map(c => [c.lat, c.lon]);

  const getMarkerColor = (idx) => {
    if (idx === 0) return '#4ade80';
    if (idx === cities.length - 1) return '#f87171';
    return '#6366f1';
  };

  const handleShare = () => {
    const itinerary = currentItinerary || generateItinerary();
    if (!itinerary) return;
    const encoded = btoa(JSON.stringify({ code: itinerary.code, name: itinerary.name, cities: tripCities.map(c => c.iata) }));
    const url = `${window.location.origin}/planner?trip=${encoded}`;
    navigator.clipboard?.writeText(url);
    alert('Share link copied to clipboard!');
  };

  const handleExportPDF = async () => {
    if (!timelineRef.current) return;
    setExporting(true);
    try {
      const canvas = await html2canvas(timelineRef.current, { backgroundColor: '#07080f', scale: 2 });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

      const title = currentItinerary?.name || 'My Trip';
      const code = currentItinerary?.code || '';
      pdf.setFontSize(24);
      pdf.setTextColor(99, 102, 241);
      pdf.text('TripFlow', 20, 20);
      pdf.setFontSize(18);
      pdf.setTextColor(226, 232, 240);
      pdf.text(title, 20, 32);
      if (code) {
        pdf.setFontSize(10);
        pdf.setTextColor(150, 150, 180);
        pdf.text(`Trip Code: ${code}`, 20, 40);
      }

      const route = tripCities.map(c => c.city).join(' → ');
      pdf.setFontSize(10);
      pdf.setTextColor(148, 163, 184);
      pdf.text(`Route: ${route}`, 20, 50);
      pdf.text(`Cities: ${tripCities.length} | Total Nights: ${tripCities.reduce((s, c) => s + (c.nights || 0), 0)}`, 20, 58);

      const imgWidth = 170;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      pdf.addImage(imgData, 'PNG', 20, 70, imgWidth, imgHeight);

      pdf.save(`${title.replace(/\s+/g, '_')}_TripFlow.pdf`);
    } catch (err) {
      console.error('PDF export failed:', err);
    }
    setExporting(false);
  };

  const handleExportPdfDocument = async () => {
    setExporting(true);
    try {
      const itinerary = currentItinerary || generateItinerary();
      if (!itinerary && tripCities.length === 0) return;

      const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 16;
      const contentWidth = pageWidth - margin * 2;
      let y = 18;

      const addPageIfNeeded = (heightNeeded) => {
        if (y + heightNeeded <= pageHeight - margin) return;
        pdf.addPage();
        y = margin;
      };

      const addWrappedText = (text, x, maxWidth, lineHeight = 5) => {
        const lines = pdf.splitTextToSize(safePdfText(text), maxWidth);
        pdf.text(lines, x, y);
        y += lines.length * lineHeight;
      };

      const title = itinerary?.name || currentItinerary?.name || 'My Trip';
      const code = itinerary?.code || currentItinerary?.code || '';
      const route = tripCities.map(c => c.city).join(' -> ');
      const totalNights = tripCities.reduce((s, c) => s + (c.nights || 0), 0);

      pdf.setFillColor(248, 250, 252);
      pdf.rect(0, 0, pageWidth, pageHeight, 'F');
      pdf.setFontSize(24);
      pdf.setTextColor(99, 102, 241);
      pdf.text('TripFlow', margin, y);
      y += 10;

      pdf.setFontSize(18);
      pdf.setTextColor(15, 23, 42);
      addWrappedText(title, margin, contentWidth, 7);

      pdf.setFontSize(10);
      pdf.setTextColor(71, 85, 105);
      if (code) {
        pdf.text(`Trip Code: ${safePdfText(code)}`, margin, y);
        y += 6;
      }
      pdf.text(`Cities: ${tripCities.length} | Total Nights: ${totalNights}`, margin, y);
      y += 6;

      pdf.setFontSize(11);
      addWrappedText(`Route: ${route || 'No route selected'}`, margin, contentWidth, 5);
      y += 6;

      pdf.setDrawColor(226, 232, 240);
      pdf.line(margin, y, pageWidth - margin, y);
      y += 10;

      pdf.setFontSize(15);
      pdf.setTextColor(15, 23, 42);
      pdf.text('Itinerary Timeline', margin, y);
      y += 9;

      tripCities.forEach((city, idx) => {
        const nextCity = tripCities[idx + 1];
        const transport = idx > 0 && city.transportMode ? `Transport from previous city: ${city.transportMode}` : '';
        const boxHeight = nextCity ? 36 : 30;
        addPageIfNeeded(boxHeight);

        pdf.setFillColor(255, 255, 255);
        pdf.setDrawColor(226, 232, 240);
        pdf.roundedRect(margin, y - 5, contentWidth, boxHeight, 2, 2, 'FD');

        const markerColor = idx === 0 ? [74, 222, 128] : idx === tripCities.length - 1 ? [248, 113, 113] : [99, 102, 241];
        pdf.setFillColor(markerColor[0], markerColor[1], markerColor[2]);
        pdf.circle(margin + 7, y + 3, 4, 'F');
        pdf.setFontSize(8);
        pdf.setTextColor(255, 255, 255);
        pdf.text(String(idx + 1), margin + 7, y + 4, { align: 'center' });

        pdf.setFontSize(13);
        pdf.setTextColor(15, 23, 42);
        pdf.text(`${safePdfText(city.city)} (${safePdfText(city.iata)})`, margin + 16, y + 1);

        pdf.setFontSize(9);
        pdf.setTextColor(71, 85, 105);
        pdf.text(safePdfText(city.country), margin + 16, y + 7);
        pdf.text(formatDateRange(city), margin + 16, y + 13);
        if (transport) pdf.text(transport, margin + 16, y + 19);
        if (nextCity) pdf.text(`Next: ${safePdfText(nextCity.city)}`, margin + 16, y + 25);

        y += boxHeight + 6;
      });

      pdf.save(makeFileName(title));
    } catch (err) {
      console.error('PDF export failed:', err);
      alert('PDF export failed. Please try again.');
    } finally {
      setExporting(false);
    }
  };

  const handleSave = () => {
    generateItinerary();
    setTimeout(saveCurrentTrip, 100);
    alert('Trip saved!');
  };

  if (tripCities.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 pt-28 pb-12 text-center">
        <Map size={64} className="text-slate-600 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-slate-100 mb-2">No itinerary to map</h2>
        <p className="text-slate-400 mb-6">Add cities in the planner to see your route on the map.</p>
        <Link to="/planner" className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-3 rounded-xl font-semibold transition-all">
          Go to Planner <ArrowRight size={16} />
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 pt-20 pb-12 animate-fade-in">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">Trip Map</h1>
          <p className="text-slate-400 text-sm">{currentItinerary?.name || 'Your Itinerary'} · {tripCities.length} cities · {tripCities.reduce((s, c) => s + (c.nights || 0), 0)} nights</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={handleShare} className="flex items-center gap-2 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-300 px-4 py-2 rounded-xl text-sm font-medium transition-all">
            <Share2 size={15} /> Share
          </button>
          <button onClick={handleExportPdfDocument} disabled={exporting} className="flex items-center gap-2 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400 px-4 py-2 rounded-xl text-sm font-medium transition-all">
            <Download size={15} /> {exporting ? 'Exporting...' : 'Export PDF'}
          </button>
          <button onClick={handleSave} className="flex items-center gap-2 bg-green-500/20 hover:bg-green-500/30 text-green-400 px-4 py-2 rounded-xl text-sm font-medium transition-all">
            <Save size={15} /> Save Trip
          </button>
          <Link to="/intelligence" className="flex items-center gap-2 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 px-4 py-2 rounded-xl text-sm font-medium transition-all">
            <Brain size={15} /> Intelligence
          </Link>
        </div>
      </div>

      {/* Map */}
      <div className="h-[450px] rounded-2xl overflow-hidden border border-white/5 mb-6">
        <MapContainer center={[20, 80]} zoom={4} style={{ height: '100%', width: '100%' }} className="z-10">
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          />
          {cities.length > 0 && <MapBounds cities={cities} />}
          {cities.length > 1 && (
            <Polyline
              positions={positions}
              pathOptions={{ color: '#6366f1', weight: 2, opacity: 0.7, dashArray: '8 6' }}
            />
          )}
          {cities.map((city, idx) => (
            <Marker key={city.iata} position={[city.lat, city.lon]} icon={createColoredIcon(getMarkerColor(idx), idx + 1)}>
              <Popup>
                <div style={{ color: '#e2e8f0', fontFamily: 'Cabinet Grotesk, sans-serif', minWidth: '160px' }}>
                  <div style={{ fontSize: '18px', marginBottom: '4px' }}>{city.emoji} <strong>{city.city}</strong></div>
                  <div style={{ color: '#94a3b8', fontSize: '12px' }}>{city.country}</div>
                  {city.arrival && <div style={{ fontSize: '12px', marginTop: '6px', color: '#a5b4fc' }}>📅 {city.arrival} → {city.departure || '?'}</div>}
                  <div style={{ fontSize: '12px', color: '#94a3b8' }}>🌙 {city.nights || 0} nights</div>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>

      {/* Timeline */}
      <div ref={timelineRef} className="bg-card border border-white/5 rounded-2xl p-6">
        <h2 className="font-bold text-slate-100 mb-5 flex items-center gap-2"><Plane size={16} className="text-indigo-400" /> Itinerary Timeline</h2>
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-5 top-0 bottom-0 w-0.5 bg-white/10" />
          <div className="space-y-6">
            {tripCities.map((city, idx) => {
              const isFirst = idx === 0;
              const isLast = idx === tripCities.length - 1;
              const nodeColor = isFirst ? '#4ade80' : isLast ? '#f87171' : '#6366f1';
              const nextCity = tripCities[idx + 1];
              const legCost = nextCity ? Math.round(8500 + Math.random() * 5000) : 0;

              return (
                <div key={city.iata} className="relative pl-14">
                  {/* Node */}
                  <div className="absolute left-3 top-0 w-5 h-5 rounded-full border-2 border-white/20 flex items-center justify-center text-xs font-bold" style={{ backgroundColor: nodeColor + '30', borderColor: nodeColor, color: nodeColor }}>
                    {idx + 1}
                  </div>
                  <div className="flex items-start justify-between flex-wrap gap-3">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{city.emoji}</span>
                      <div>
                        <h3 className="font-semibold text-slate-100">{city.city}</h3>
                        <p className="text-xs text-slate-500">{city.country} · {city.iata}</p>
                        {city.arrival && (
                          <p className="text-xs text-slate-400 mt-1">
                            {city.arrival} → {city.departure || '?'} · {city.nights || 0} nights
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {city.transportMode && idx > 0 && (
                        <span className="text-xs bg-indigo-600/10 text-indigo-400 border border-indigo-500/20 px-2 py-1 rounded-lg">
                          {TRANSPORT_EMOJI[city.transportMode] || '✈️'} {city.transportMode}
                        </span>
                      )}
                    </div>
                  </div>
                  {nextCity && (
                    <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
                      <ArrowRight size={12} />
                      <span>Next: {nextCity.city}</span>
                      {city.transportMode && <span className="text-indigo-400 font-medium">· Est. ₹{legCost.toLocaleString()}</span>}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
