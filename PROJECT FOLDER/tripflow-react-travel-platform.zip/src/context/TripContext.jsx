import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

const TripContext = createContext(null);

const generateTripCode = () => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = 'TRIP-';
  for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
};

const generateUserId = () => 'user_' + Math.random().toString(36).substr(2, 9);

const loadFromStorage = (key, fallback) => {
  try {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : fallback;
  } catch { return fallback; }
};

const saveToStorage = (key, value) => {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
};

export const TripProvider = ({ children }) => {
  const [user, setUser] = useState(() => loadFromStorage('tf_user', null));
  const [tripCities, setTripCities] = useState(() => loadFromStorage('tf_tripCities', []));
  const [tripName, setTripName] = useState(() => loadFromStorage('tf_tripName', ''));
  const [tripCode, setTripCode] = useState(() => loadFromStorage('tf_tripCode', generateTripCode()));
  const [nationality, setNationality] = useState(() => loadFromStorage('tf_nationality', 'Indian'));
  const [travelerType, setTravelerType] = useState(() => loadFromStorage('tf_travelerType', 'Solo'));
  const [currentItinerary, setCurrentItinerary] = useState(() => loadFromStorage('tf_currentItinerary', null));
  const [savedTrips, setSavedTrips] = useState(() => loadFromStorage('tf_savedTrips', []));
  const [checkedPackingItems, setCheckedPackingItems] = useState(() => loadFromStorage('tf_packingItems', {}));
  const [budgetTier, setBudgetTier] = useState('midrange');

  useEffect(() => { saveToStorage('tf_user', user); }, [user]);
  useEffect(() => { saveToStorage('tf_tripCities', tripCities); }, [tripCities]);
  useEffect(() => { saveToStorage('tf_tripName', tripName); }, [tripName]);
  useEffect(() => { saveToStorage('tf_tripCode', tripCode); }, [tripCode]);
  useEffect(() => { saveToStorage('tf_nationality', nationality); }, [nationality]);
  useEffect(() => { saveToStorage('tf_travelerType', travelerType); }, [travelerType]);
  useEffect(() => { saveToStorage('tf_currentItinerary', currentItinerary); }, [currentItinerary]);
  useEffect(() => { saveToStorage('tf_savedTrips', savedTrips); }, [savedTrips]);
  useEffect(() => { saveToStorage('tf_packingItems', checkedPackingItems); }, [checkedPackingItems]);

  const login = useCallback((userData) => {
    const userObj = { ...userData, userId: userData.userId || generateUserId() };
    setUser(userObj);
    saveToStorage('tf_user', userObj);
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    saveToStorage('tf_user', null);
  }, []);

  const register = useCallback((userData) => {
    const userObj = { ...userData, userId: generateUserId(), createdAt: new Date().toISOString() };
    setUser(userObj);
    saveToStorage('tf_user', userObj);
    return userObj;
  }, []);

  const addCity = useCallback((airport) => {
    setTripCities(prev => {
      if (prev.find(c => c.iata === airport.iata)) return prev;
      return [...prev, {
        ...airport,
        arrival: '',
        departure: '',
        nights: 3,
        transportMode: prev.length === 0 ? null : 'Flight',
        id: Date.now() + Math.random(),
      }];
    });
  }, []);

  const removeCity = useCallback((iata) => {
    setTripCities(prev => prev.filter(c => c.iata !== iata));
  }, []);

  const updateCity = useCallback((iata, updates) => {
    setTripCities(prev => prev.map(c => c.iata === iata ? { ...c, ...updates } : c));
  }, []);

  const reorderCities = useCallback((fromIndex, toIndex) => {
    setTripCities(prev => {
      const arr = [...prev];
      const [moved] = arr.splice(fromIndex, 1);
      arr.splice(toIndex, 0, moved);
      return arr;
    });
  }, []);

  const generateItinerary = useCallback(() => {
    if (tripCities.length === 0) return;
    const itinerary = {
      id: Date.now(),
      code: tripCode,
      name: tripName || 'My Trip',
      cities: tripCities,
      nationality,
      travelerType,
      generatedAt: new Date().toISOString(),
      totalNights: tripCities.reduce((sum, c) => sum + (c.nights || 0), 0),
    };
    setCurrentItinerary(itinerary);
    return itinerary;
  }, [tripCities, tripCode, tripName, nationality, travelerType]);

  const saveCurrentTrip = useCallback(() => {
    if (!currentItinerary) return;
    setSavedTrips(prev => {
      const exists = prev.find(t => t.id === currentItinerary.id);
      if (exists) return prev.map(t => t.id === currentItinerary.id ? currentItinerary : t);
      return [...prev, currentItinerary];
    });
  }, [currentItinerary]);

  const deleteSavedTrip = useCallback((id) => {
    setSavedTrips(prev => prev.filter(t => t.id !== id));
  }, []);

  const loadSavedTrip = useCallback((trip) => {
    setTripCities(trip.cities || []);
    setTripName(trip.name || '');
    setTripCode(trip.code || generateTripCode());
    setNationality(trip.nationality || 'Indian');
    setTravelerType(trip.travelerType || 'Solo');
    setCurrentItinerary(trip);
  }, []);

  const clearTrip = useCallback(() => {
    setTripCities([]);
    setTripName('');
    setTripCode(generateTripCode());
    setCurrentItinerary(null);
  }, []);

  const togglePackingItem = useCallback((key) => {
    setCheckedPackingItems(prev => ({ ...prev, [key]: !prev[key] }));
  }, []);

  const regenerateTripCode = useCallback(() => {
    const code = generateTripCode();
    setTripCode(code);
  }, []);

  const value = {
    user, login, logout, register,
    tripCities, addCity, removeCity, updateCity, reorderCities,
    tripName, setTripName,
    tripCode, regenerateTripCode,
    nationality, setNationality,
    travelerType, setTravelerType,
    currentItinerary, setCurrentItinerary, generateItinerary,
    savedTrips, saveCurrentTrip, deleteSavedTrip, loadSavedTrip,
    checkedPackingItems, togglePackingItem,
    clearTrip,
    budgetTier, setBudgetTier,
  };

  return <TripContext.Provider value={value}>{children}</TripContext.Provider>;
};

export const useTripContext = () => {
  const ctx = useContext(TripContext);
  if (!ctx) throw new Error('useTripContext must be used inside TripProvider');
  return ctx;
};
