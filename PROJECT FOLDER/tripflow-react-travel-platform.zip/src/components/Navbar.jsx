import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useTripContext } from '../context/TripContext';
import { Map, Compass, BookOpen, Heart, Users, LayoutDashboard, Menu, X, Plane, Brain } from 'lucide-react';

const navLinks = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/planner', label: 'Planner', icon: Plane },
  { to: '/explore', label: 'Explore', icon: Compass },
  { to: '/map', label: 'Map', icon: Map },
  { to: '/saved', label: 'Saved', icon: Heart },
  { to: '/community', label: 'Community', icon: Users },
  { to: '/intelligence', label: 'Intelligence', icon: Brain },
];

export default function Navbar() {
  const { user, logout, tripCities } = useTripContext();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
    setMobileOpen(false);
  };

  const isActive = (path) => location.pathname === path || location.pathname.startsWith(path + '/');

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center glow-primary">
            <Plane size={16} className="text-white" />
          </div>
          <span className="font-bold text-lg">
            Trip<span className="text-indigo-400">Flow</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        {user && (
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map(({ to, label, icon: Icon }) => (
              <Link
                key={to}
                to={to}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  isActive(to)
                    ? 'bg-indigo-600/20 text-indigo-400'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                }`}
              >
                <Icon size={15} />
                {label}
                {to === '/planner' && tripCities.length > 0 && (
                  <span className="ml-1 bg-indigo-600 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center font-bold">
                    {tripCities.length}
                  </span>
                )}
              </Link>
            ))}
          </div>
        )}

        {/* Right side */}
        <div className="flex items-center gap-3">
          {user ? (
            <div className="flex items-center gap-3">
              <div className="hidden sm:flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center text-sm font-bold text-white">
                  {user.name?.[0]?.toUpperCase() || 'U'}
                </div>
                <span className="text-sm text-slate-300 hidden lg:block">{user.name}</span>
              </div>
              <button
                onClick={handleLogout}
                className="hidden sm:block text-xs text-slate-500 hover:text-slate-300 transition-colors px-2 py-1 rounded border border-white/10 hover:border-white/20"
              >
                Sign out
              </button>
            </div>
          ) : (
            <div className="hidden sm:flex items-center gap-2">
              <Link to="/login" className="text-sm text-slate-400 hover:text-slate-200 px-3 py-1.5 rounded-lg transition-colors">
                Sign in
              </Link>
              <Link to="/signup" className="text-sm bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-1.5 rounded-lg transition-colors font-medium">
                Get started
              </Link>
            </div>
          )}

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-white/5 transition-colors"
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden glass border-t border-white/5 py-4 px-4 animate-fade-in">
          {user ? (
            <>
              <div className="flex items-center gap-3 mb-4 pb-4 border-b border-white/10">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center text-sm font-bold text-white">
                  {user.name?.[0]?.toUpperCase() || 'U'}
                </div>
                <div>
                  <div className="font-medium text-slate-200">{user.name}</div>
                  <div className="text-xs text-slate-500">{user.email}</div>
                </div>
              </div>
              <div className="space-y-1">
                {navLinks.map(({ to, label, icon: Icon }) => (
                  <Link
                    key={to}
                    to={to}
                    onClick={() => setMobileOpen(false)}
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                      isActive(to)
                        ? 'bg-indigo-600/20 text-indigo-400'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                    }`}
                  >
                    <Icon size={16} />
                    {label}
                  </Link>
                ))}
                <button
                  onClick={handleLogout}
                  className="w-full text-left flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-slate-500 hover:text-slate-300 hover:bg-white/5 transition-all mt-2"
                >
                  Sign out
                </button>
              </div>
            </>
          ) : (
            <div className="space-y-2">
              <Link to="/login" onClick={() => setMobileOpen(false)} className="block text-center py-2.5 text-slate-300 hover:text-white transition-colors">
                Sign in
              </Link>
              <Link to="/signup" onClick={() => setMobileOpen(false)} className="block text-center py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-medium transition-colors">
                Get started
              </Link>
            </div>
          )}
        </div>
      )}
    </nav>
  );
}
