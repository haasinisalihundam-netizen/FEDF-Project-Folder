import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useTripContext } from '../context/TripContext';

export default function ProtectedRoute({ children }) {
  const { user } = useTripContext();
  const location = useLocation();

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
}
