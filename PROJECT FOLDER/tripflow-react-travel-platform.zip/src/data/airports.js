export const airports = [
  // India
  { iata: "DEL", city: "New Delhi", country: "India", region: "Asia", emoji: "🏛️", lat: 28.6139, lon: 77.2090, tag: "Heritage", description: "India's capital blending Mughal grandeur with modern India.", rating: 4.8 },
  { iata: "BOM", city: "Mumbai", country: "India", region: "Asia", emoji: "🌆", lat: 19.0760, lon: 72.8777, tag: "Metropolis", description: "India's financial capital and Bollywood heartland.", rating: 4.7 },
  { iata: "JAI", city: "Jaipur", country: "India", region: "Asia", emoji: "🏰", lat: 26.9124, lon: 75.7873, tag: "Heritage", description: "The Pink City of Rajputana palaces and vibrant bazaars.", rating: 4.8 },
  { iata: "GOI", city: "Goa", country: "India", region: "Asia", emoji: "🏖️", lat: 15.2993, lon: 74.1240, tag: "Beach", description: "India's beach paradise with Portuguese colonial charm.", rating: 4.7 },
  { iata: "AGR", city: "Agra", country: "India", region: "Asia", emoji: "🕌", lat: 27.1767, lon: 78.0081, tag: "Heritage", description: "Home to the iconic Taj Mahal, a UNESCO World Heritage Site.", rating: 4.9 },
  { iata: "VNS", city: "Varanasi", country: "India", region: "Asia", emoji: "🪔", lat: 25.3176, lon: 82.9739, tag: "Spiritual", description: "One of the world's oldest cities and Hinduism's holiest site.", rating: 4.8 },
  { iata: "CCU", city: "Kolkata", country: "India", region: "Asia", emoji: "🎨", lat: 22.5726, lon: 88.3639, tag: "Culture", description: "City of joy with colonial heritage and vibrant arts scene.", rating: 4.5 },
  { iata: "MAA", city: "Chennai", country: "India", region: "Asia", emoji: "🎭", lat: 13.0827, lon: 80.2707, tag: "Culture", description: "Gateway to South India with classical arts and temples.", rating: 4.4 },
  { iata: "HYD", city: "Hyderabad", country: "India", region: "Asia", emoji: "💎", lat: 17.3850, lon: 78.4867, tag: "Tech Hub", description: "City of pearls and biryani with a booming tech scene.", rating: 4.5 },
  { iata: "BLR", city: "Bengaluru", country: "India", region: "Asia", emoji: "🌿", lat: 12.9716, lon: 77.5946, tag: "Tech Hub", description: "India's Silicon Valley with pleasant climate and gardens.", rating: 4.4 },
  // Southeast Asia
  { iata: "SIN", city: "Singapore", country: "Singapore", region: "Asia", emoji: "🦁", lat: 1.3521, lon: 103.8198, tag: "City-State", description: "Ultra-modern city-state fusing Asian cultures with world-class infrastructure.", rating: 4.9 },
  { iata: "BKK", city: "Bangkok", country: "Thailand", region: "Asia", emoji: "🛕", lat: 13.7563, lon: 100.5018, tag: "Culture", description: "Thailand's dazzling capital with ornate temples and street food paradise.", rating: 4.8 },
  { iata: "HKT", city: "Phuket", country: "Thailand", region: "Asia", emoji: "🏝️", lat: 7.8804, lon: 98.3923, tag: "Beach", description: "Thailand's largest island with stunning beaches and vibrant nightlife.", rating: 4.7 },
  { iata: "DPS", city: "Bali", country: "Indonesia", region: "Asia", emoji: "🌺", lat: -8.3405, lon: 115.0920, tag: "Beach", description: "Island of the Gods with terraced rice fields and spiritual temples.", rating: 4.9 },
  { iata: "KUL", city: "Kuala Lumpur", country: "Malaysia", region: "Asia", emoji: "🏙️", lat: 3.1390, lon: 101.6869, tag: "Metropolis", description: "Cosmopolitan capital with the iconic Petronas Twin Towers.", rating: 4.6 },
  { iata: "HAN", city: "Hanoi", country: "Vietnam", region: "Asia", emoji: "🌿", lat: 21.0278, lon: 105.8342, tag: "Heritage", description: "Vietnam's ancient capital with French colonial boulevards and street life.", rating: 4.6 },
  { iata: "SGN", city: "Ho Chi Minh City", country: "Vietnam", region: "Asia", emoji: "🛵", lat: 10.8231, lon: 106.6297, tag: "Metropolis", description: "Vietnam's dynamic southern metropolis buzzing with energy.", rating: 4.5 },
  { iata: "REP", city: "Siem Reap", country: "Cambodia", region: "Asia", emoji: "🏯", lat: 13.3671, lon: 103.8448, tag: "Heritage", description: "Gateway to Angkor Wat, the world's largest religious monument.", rating: 4.8 },
  { iata: "RGN", city: "Yangon", country: "Myanmar", region: "Asia", emoji: "🌟", lat: 16.8661, lon: 96.1951, tag: "Heritage", description: "Myanmar's former capital with the golden Shwedagon Pagoda.", rating: 4.4 },
  { iata: "MNL", city: "Manila", country: "Philippines", region: "Asia", emoji: "🌴", lat: 14.5995, lon: 120.9842, tag: "Metropolis", description: "Philippines' vibrant capital with Spanish colonial history.", rating: 4.2 },
  // East Asia
  { iata: "NRT", city: "Tokyo", country: "Japan", region: "Asia", emoji: "⛩️", lat: 35.6762, lon: 139.6503, tag: "Metropolis", description: "Japan's electrifying capital blending ultramodern and traditional.", rating: 4.9 },
  { iata: "ITM", city: "Kyoto", country: "Japan", region: "Asia", emoji: "🌸", lat: 35.0116, lon: 135.7681, tag: "Heritage", description: "Japan's cultural heart with thousands of temples and geisha districts.", rating: 4.9 },
  { iata: "KIX", city: "Osaka", country: "Japan", region: "Asia", emoji: "🍜", lat: 34.6937, lon: 135.5023, tag: "Food", description: "Japan's kitchen and street food capital with infectious energy.", rating: 4.8 },
  { iata: "ICN", city: "Seoul", country: "South Korea", region: "Asia", emoji: "🎮", lat: 37.5665, lon: 126.9780, tag: "Metropolis", description: "Dynamic Korean capital fusing K-pop culture with ancient palaces.", rating: 4.7 },
  { iata: "PEK", city: "Beijing", country: "China", region: "Asia", emoji: "🏯", lat: 39.9042, lon: 116.4074, tag: "Heritage", description: "China's imperial capital with the Forbidden City and Great Wall.", rating: 4.7 },
  { iata: "PVG", city: "Shanghai", country: "China", region: "Asia", emoji: "🌃", lat: 31.2304, lon: 121.4737, tag: "Metropolis", description: "China's global financial hub with a stunning skyline and culture.", rating: 4.7 },
  { iata: "HKG", city: "Hong Kong", country: "Hong Kong", region: "Asia", emoji: "🌆", lat: 22.3193, lon: 114.1694, tag: "Metropolis", description: "Asia's world city with dramatic skyline, dim sum and hiking trails.", rating: 4.8 },
  // Middle East
  { iata: "DXB", city: "Dubai", country: "UAE", region: "Middle East", emoji: "🏙️", lat: 25.2048, lon: 55.2708, tag: "Luxury", description: "Futuristic desert metropolis with record-breaking attractions.", rating: 4.8 },
  { iata: "AUH", city: "Abu Dhabi", country: "UAE", region: "Middle East", emoji: "🕌", lat: 24.4539, lon: 54.3773, tag: "Luxury", description: "UAE's capital with the stunning Sheikh Zayed Grand Mosque.", rating: 4.7 },
  { iata: "DOH", city: "Doha", country: "Qatar", region: "Middle East", emoji: "🌟", lat: 25.2854, lon: 51.5310, tag: "Luxury", description: "Qatar's ultramodern capital on the Arabian Gulf with world-class museums.", rating: 4.6 },
  { iata: "IST", city: "Istanbul", country: "Turkey", region: "Middle East", emoji: "🌉", lat: 41.0082, lon: 28.9784, tag: "Heritage", description: "Transcontinental city bridging Europe and Asia with Ottoman grandeur.", rating: 4.9 },
  { iata: "AMM", city: "Amman", country: "Jordan", region: "Middle East", emoji: "🏛️", lat: 31.9454, lon: 35.9284, tag: "Heritage", description: "Jordan's modern capital close to ancient Petra and Wadi Rum.", rating: 4.5 },
  // Europe
  { iata: "CDG", city: "Paris", country: "France", region: "Europe", emoji: "🗼", lat: 48.8566, lon: 2.3522, tag: "Romance", description: "The City of Light with iconic art, cuisine and the Eiffel Tower.", rating: 4.9 },
  { iata: "LHR", city: "London", country: "UK", region: "Europe", emoji: "🎡", lat: 51.5074, lon: -0.1278, tag: "Metropolis", description: "Global capital with royal heritage, world-class museums and theatre.", rating: 4.8 },
  { iata: "FCO", city: "Rome", country: "Italy", region: "Europe", emoji: "🏛️", lat: 41.9028, lon: 12.4964, tag: "Heritage", description: "The Eternal City with 3,000 years of history at every corner.", rating: 4.9 },
  { iata: "BCN", city: "Barcelona", country: "Spain", region: "Europe", emoji: "🎨", lat: 41.3851, lon: 2.1734, tag: "Culture", description: "Gaudí's city with stunning architecture, beaches and Catalan cuisine.", rating: 4.8 },
  { iata: "AMS", city: "Amsterdam", country: "Netherlands", region: "Europe", emoji: "🌷", lat: 52.3676, lon: 4.9041, tag: "Culture", description: "The Venice of the North with canals, museums and liberal spirit.", rating: 4.7 },
  { iata: "PRG", city: "Prague", country: "Czech Republic", region: "Europe", emoji: "🏰", lat: 50.0755, lon: 14.4378, tag: "Heritage", description: "The Golden City with well-preserved medieval architecture.", rating: 4.8 },
  { iata: "VIE", city: "Vienna", country: "Austria", region: "Europe", emoji: "🎼", lat: 48.2082, lon: 16.3738, tag: "Culture", description: "Imperial city with magnificent palaces and classical music legacy.", rating: 4.7 },
  { iata: "ATH", city: "Athens", country: "Greece", region: "Europe", emoji: "🏛️", lat: 37.9838, lon: 23.7275, tag: "Heritage", description: "Cradle of Western civilization with the iconic Acropolis.", rating: 4.7 },
  { iata: "ZRH", city: "Zurich", country: "Switzerland", region: "Europe", emoji: "🏔️", lat: 47.3769, lon: 8.5417, tag: "Luxury", description: "Switzerland's largest city with Alpine views and global finance.", rating: 4.6 },
  // Americas
  { iata: "JFK", city: "New York", country: "USA", region: "Americas", emoji: "🗽", lat: 40.7128, lon: -74.0060, tag: "Metropolis", description: "The Big Apple — culture, finance, fashion and iconic skyline.", rating: 4.9 },
  { iata: "LAX", city: "Los Angeles", country: "USA", region: "Americas", emoji: "🎬", lat: 34.0522, lon: -118.2437, tag: "Culture", description: "City of Angels with Hollywood, beaches and year-round sunshine.", rating: 4.6 },
  { iata: "SFO", city: "San Francisco", country: "USA", region: "Americas", emoji: "🌁", lat: 37.7749, lon: -122.4194, tag: "Tech Hub", description: "Iconic Bay Area city with the Golden Gate Bridge and tech culture.", rating: 4.7 },
  { iata: "MIA", city: "Miami", country: "USA", region: "Americas", emoji: "🌴", lat: 25.7617, lon: -80.1918, tag: "Beach", description: "Tropical metropolis with Art Deco, Latin culture and white beaches.", rating: 4.6 },
  { iata: "CUN", city: "Cancún", country: "Mexico", region: "Americas", emoji: "🏖️", lat: 21.1619, lon: -86.8515, tag: "Beach", description: "Mexico's Caribbean resort with crystal waters and Mayan ruins nearby.", rating: 4.6 },
  { iata: "GRU", city: "São Paulo", country: "Brazil", region: "Americas", emoji: "🌇", lat: -23.5505, lon: -46.6333, tag: "Metropolis", description: "South America's largest city and financial powerhouse.", rating: 4.4 },
  { iata: "GIG", city: "Rio de Janeiro", country: "Brazil", region: "Americas", emoji: "🏟️", lat: -22.9068, lon: -43.1729, tag: "Culture", description: "Marvelous City with Christ the Redeemer, Carnival and Copacabana.", rating: 4.7 },
  { iata: "LIM", city: "Lima", country: "Peru", region: "Americas", emoji: "🦙", lat: -12.0464, lon: -77.0428, tag: "Heritage", description: "Peru's capital with world-class gastronomy and colonial history.", rating: 4.5 },
  { iata: "BOG", city: "Bogotá", country: "Colombia", region: "Americas", emoji: "☕", lat: 4.7110, lon: -74.0721, tag: "Culture", description: "Colombia's high-altitude capital with vibrant arts and coffee culture.", rating: 4.4 },
  { iata: "YYZ", city: "Toronto", country: "Canada", region: "Americas", emoji: "🍁", lat: 43.6532, lon: -79.3832, tag: "Metropolis", description: "Canada's largest city, the most multicultural on Earth.", rating: 4.6 },
  // Africa
  { iata: "CAI", city: "Cairo", country: "Egypt", region: "Africa", emoji: "🐪", lat: 30.0444, lon: 31.2357, tag: "Heritage", description: "Gateway to the ancient wonders — pyramids, Sphinx and Nile.", rating: 4.7 },
  { iata: "CPT", city: "Cape Town", country: "South Africa", region: "Africa", emoji: "🏔️", lat: -33.9249, lon: 18.4241, tag: "Scenic", description: "Breathtaking city beneath Table Mountain with wine estates and beaches.", rating: 4.9 },
  { iata: "JNB", city: "Johannesburg", country: "South Africa", region: "Africa", emoji: "💎", lat: -26.2041, lon: 28.0473, tag: "Metropolis", description: "Africa's economic powerhouse and gateway to safaris.", rating: 4.3 },
  { iata: "MBA", city: "Mombasa", country: "Kenya", region: "Africa", emoji: "🌊", lat: -4.0435, lon: 39.6682, tag: "Beach", description: "Kenya's coastal gem with Swahili culture and Indian Ocean beaches.", rating: 4.5 },
  { iata: "NBO", city: "Nairobi", country: "Kenya", region: "Africa", emoji: "🦁", lat: -1.2921, lon: 36.8219, tag: "Safari", description: "Safari capital with a national park within city limits.", rating: 4.5 },
  { iata: "TUN", city: "Tunis", country: "Tunisia", region: "Africa", emoji: "🕌", lat: 36.8065, lon: 10.1815, tag: "Heritage", description: "North African gem with ancient Carthage ruins and medina.", rating: 4.4 },
  { iata: "CMN", city: "Marrakech", country: "Morocco", region: "Africa", emoji: "🏺", lat: 31.6295, lon: -7.9811, tag: "Culture", description: "Morocco's Red City with vibrant souks, palaces and the Sahara.", rating: 4.8 },
  // Oceania
  { iata: "SYD", city: "Sydney", country: "Australia", region: "Oceania", emoji: "🌉", lat: -33.8688, lon: 151.2093, tag: "Metropolis", description: "Australia's iconic harbour city with the Opera House and Bondi Beach.", rating: 4.9 },
  { iata: "MEL", city: "Melbourne", country: "Australia", region: "Oceania", emoji: "☕", lat: -37.8136, lon: 144.9631, tag: "Culture", description: "Australia's cultural capital with world-class coffee and arts.", rating: 4.7 },
  { iata: "AKL", city: "Auckland", country: "New Zealand", region: "Oceania", emoji: "🌿", lat: -36.8485, lon: 174.7633, tag: "Adventure", description: "New Zealand's City of Sails with volcanic landscapes.", rating: 4.6 },
  { iata: "CHC", city: "Christchurch", country: "New Zealand", region: "Oceania", emoji: "🌷", lat: -43.5321, lon: 172.6362, tag: "Scenic", description: "Gateway to the Southern Alps and Canterbury Plains.", rating: 4.5 },
  { iata: "NAN", city: "Nadi", country: "Fiji", region: "Oceania", emoji: "🌺", lat: -17.7765, lon: 177.4356, tag: "Beach", description: "Fiji's main gateway with coral reefs and tropical luxury.", rating: 4.7 },
  // Additional Asia
  { iata: "CMB", city: "Colombo", country: "Sri Lanka", region: "Asia", emoji: "🌴", lat: 6.9271, lon: 79.8612, tag: "Culture", description: "Sri Lanka's vibrant capital with colonial history and spice markets.", rating: 4.4 },
  { iata: "MLE", city: "Malé", country: "Maldives", region: "Asia", emoji: "🐠", lat: 4.1755, lon: 73.5093, tag: "Beach", description: "The Maldives capital, gateway to overwater bungalows and turquoise atolls.", rating: 4.8 },
  { iata: "KTM", city: "Kathmandu", country: "Nepal", region: "Asia", emoji: "🏔️", lat: 27.7172, lon: 85.3240, tag: "Adventure", description: "Himalayan gateway city with ancient stupas and trekking culture.", rating: 4.6 },
  { iata: "DAC", city: "Dhaka", country: "Bangladesh", region: "Asia", emoji: "🌿", lat: 23.8103, lon: 90.4125, tag: "Culture", description: "Bangladesh's bustling capital on the Buriganga River.", rating: 4.0 },
  { iata: "TLV", city: "Tel Aviv", country: "Israel", region: "Middle East", emoji: "🌊", lat: 32.0853, lon: 34.7818, tag: "Beach", description: "The White City with modernist architecture, beaches and nightlife.", rating: 4.6 },
  { iata: "BEY", city: "Beirut", country: "Lebanon", region: "Middle East", emoji: "🌹", lat: 33.8938, lon: 35.5018, tag: "Culture", description: "The Paris of the Middle East with vibrant food scene and nightlife.", rating: 4.3 },
  { iata: "MCT", city: "Muscat", country: "Oman", region: "Middle East", emoji: "🏜️", lat: 23.5880, lon: 58.3829, tag: "Heritage", description: "Oman's elegant capital blending tradition with modern luxury.", rating: 4.6 },
  { iata: "RUH", city: "Riyadh", country: "Saudi Arabia", region: "Middle East", emoji: "🌆", lat: 24.6877, lon: 46.7219, tag: "Metropolis", description: "Saudi Arabia's rapidly modernizing capital in the heart of Arabia.", rating: 4.2 },
  // More Europe
  { iata: "MAD", city: "Madrid", country: "Spain", region: "Europe", emoji: "🎭", lat: 40.4168, lon: -3.7038, tag: "Culture", description: "Spain's passionate capital with world-class art and tapas culture.", rating: 4.7 },
  { iata: "MXP", city: "Milan", country: "Italy", region: "Europe", emoji: "👗", lat: 45.4642, lon: 9.1900, tag: "Luxury", description: "Italy's fashion and design capital with the magnificent Duomo.", rating: 4.6 },
  { iata: "LIS", city: "Lisbon", country: "Portugal", region: "Europe", emoji: "🎵", lat: 38.7223, lon: -9.1393, tag: "Culture", description: "Europe's sunniest capital with fado music and tiled buildings.", rating: 4.8 },
  { iata: "DUB", city: "Dublin", country: "Ireland", region: "Europe", emoji: "🍀", lat: 53.3498, lon: -6.2603, tag: "Culture", description: "Ireland's friendly capital with Celtic heritage and pub culture.", rating: 4.5 },
  { iata: "CPH", city: "Copenhagen", country: "Denmark", region: "Europe", emoji: "🚲", lat: 55.6761, lon: 12.5683, tag: "Culture", description: "Scandinavia's happiest city with New Nordic cuisine and design.", rating: 4.7 },
  { iata: "STO", city: "Stockholm", country: "Sweden", region: "Europe", emoji: "🌊", lat: 59.3293, lon: 18.0686, tag: "Culture", description: "Built on 14 islands with Viking history and modern Scandinavian style.", rating: 4.7 },
  { iata: "HEL", city: "Helsinki", country: "Finland", region: "Europe", emoji: "🎿", lat: 60.1699, lon: 24.9384, tag: "Culture", description: "Finland's elegant capital with design district and sauna culture.", rating: 4.5 },
  { iata: "WAW", city: "Warsaw", country: "Poland", region: "Europe", emoji: "🏛️", lat: 52.2297, lon: 21.0122, tag: "Heritage", description: "Poland's resilient capital with a beautifully rebuilt old town.", rating: 4.5 },
  { iata: "BUD", city: "Budapest", country: "Hungary", region: "Europe", emoji: "🛁", lat: 47.4979, lon: 19.0402, tag: "Heritage", description: "The Pearl of the Danube with thermal baths and grand architecture.", rating: 4.8 },
  // More Americas
  { iata: "MEX", city: "Mexico City", country: "Mexico", region: "Americas", emoji: "🌮", lat: 19.4326, lon: -99.1332, tag: "Culture", description: "Vast Aztec-founded metropolis with superb museums and cuisine.", rating: 4.6 },
  { iata: "SCL", city: "Santiago", country: "Chile", region: "Americas", emoji: "🍷", lat: -33.4489, lon: -70.6693, tag: "Culture", description: "Chile's sophisticated capital between the Andes and Pacific.", rating: 4.5 },
  { iata: "EZE", city: "Buenos Aires", country: "Argentina", region: "Americas", emoji: "💃", lat: -34.6037, lon: -58.3816, tag: "Culture", description: "South America's Paris with tango, steak and European flair.", rating: 4.6 },
  { iata: "ORD", city: "Chicago", country: "USA", region: "Americas", emoji: "🏙️", lat: 41.8781, lon: -87.6298, tag: "Metropolis", description: "The Windy City with stunning architecture, blues music and deep-dish pizza.", rating: 4.6 },
  { iata: "LAS", city: "Las Vegas", country: "USA", region: "Americas", emoji: "🎰", lat: 36.1699, lon: -115.1398, tag: "Entertainment", description: "The Entertainment Capital of the World in the Nevada desert.", rating: 4.5 },
];

export const getAirportByIata = (iata) => airports.find(a => a.iata === iata);
export const getAirportsByRegion = (region) => region === 'All' ? airports : airports.filter(a => a.region === region);
export const searchAirports = (query) => {
  const q = query.toLowerCase();
  return airports.filter(a =>
    a.city.toLowerCase().includes(q) ||
    a.country.toLowerCase().includes(q) ||
    a.iata.toLowerCase().includes(q)
  );
};
export const getCitySlug = (city) => city.toLowerCase().replace(/\s+/g, '-');
export const getByCitySlug = (slug) => airports.find(a => getCitySlug(a.city) === slug);
