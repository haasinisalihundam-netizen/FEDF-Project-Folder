export const transportRoutes = {
  "DEL-AGR": {
    flight: { available: false },
    train: [{ name: "Gatimaan Express", number: "12050", duration: "1h 40m", classes: { SL: { price: 255, avail: "Available" }, "3AC": { price: 680, avail: "Available" }, "2AC": { price: 975, avail: "Moderate" }, "1AC": { price: 1620, avail: "Low" } }, link: "https://www.irctc.co.in" }],
    bus: [{ operator: "Rajasthan Roadways", duration: "3.5 hrs", price: "₹200–350", link: "https://www.redbus.in" }],
    drive: { distance: 233, fuelCost: 1400, toll: 250 },
  },
  "DEL-JAI": {
    flight: [{ airline: "IndiGo", code: "6E", duration: "1h 05m", minPrice: 2800, maxPrice: 6500, link: "https://www.google.com/flights" }],
    train: [{ name: "Shatabdi Express", number: "12015", duration: "4h 25m", classes: { CC: { price: 905, avail: "Available" }, "EC": { price: 1700, avail: "Moderate" } }, link: "https://www.irctc.co.in" }],
    bus: [{ operator: "Rajasthan Roadways", duration: "5 hrs", price: "₹300–600", link: "https://www.redbus.in" }],
    drive: { distance: 280, fuelCost: 1680, toll: 350 },
  },
  "DEL-BOM": {
    flight: [{ airline: "IndiGo", code: "6E", duration: "2h 15m", minPrice: 3500, maxPrice: 12000, link: "https://www.google.com/flights" }, { airline: "Air India", code: "AI", duration: "2h 20m", minPrice: 4200, maxPrice: 15000, link: "https://www.google.com/flights" }],
    train: [{ name: "Rajdhani Express", number: "12951", duration: "15h 35m", classes: { "3AC": { price: 1695, avail: "Available" }, "2AC": { price: 2285, avail: "Moderate" }, "1AC": { price: 3940, avail: "Available" } }, link: "https://www.irctc.co.in" }],
    bus: [{ operator: "VRL Travels", duration: "20 hrs", price: "₹800–1,800", link: "https://www.redbus.in" }],
    drive: { distance: 1415, fuelCost: 8490, toll: 1200 },
  },
  "BOM-GOI": {
    flight: [{ airline: "IndiGo", code: "6E", duration: "1h 10m", minPrice: 2500, maxPrice: 8000, link: "https://www.google.com/flights" }],
    train: [{ name: "Mandovi Express", number: "10103", duration: "8h 40m", classes: { SL: { price: 310, avail: "Available" }, "3AC": { price: 850, avail: "Available" }, "2AC": { price: 1215, avail: "Moderate" } }, link: "https://www.irctc.co.in" }],
    bus: [{ operator: "Patel Travels", duration: "9 hrs", price: "₹500–1,200", link: "https://www.redbus.in" }],
    drive: { distance: 593, fuelCost: 3558, toll: 600 },
  },
  "DEL-SIN": {
    flight: [{ airline: "Singapore Airlines", code: "SQ", duration: "5h 30m", minPrice: 22000, maxPrice: 65000, link: "https://www.google.com/flights" }, { airline: "IndiGo", code: "6E", duration: "5h 45m", minPrice: 18000, maxPrice: 48000, link: "https://www.google.com/flights" }],
    drive: null,
    bus: null,
    train: null,
  },
  "SIN-BKK": {
    flight: [{ airline: "Scoot", code: "TR", duration: "2h 30m", minPrice: 8000, maxPrice: 22000, link: "https://www.google.com/flights" }, { airline: "Thai Airways", code: "TG", duration: "2h 25m", minPrice: 11000, maxPrice: 35000, link: "https://www.google.com/flights" }],
    drive: null,
    bus: null,
    train: null,
  },
  "BKK-HKT": {
    flight: [{ airline: "Thai AirAsia", code: "FD", duration: "1h 20m", minPrice: 3500, maxPrice: 9000, link: "https://www.google.com/flights" }],
    bus: [{ operator: "Phuket Bus", duration: "12 hrs", price: "₹800–1,500", link: "https://www.redbus.in" }],
    drive: { distance: 862, fuelCost: 5200, toll: 0 },
    train: null,
  },
  "BKK-DPS": {
    flight: [{ airline: "Citilink", code: "QG", duration: "4h 20m", minPrice: 12000, maxPrice: 32000, link: "https://www.google.com/flights" }, { airline: "Thai Airways", code: "TG", duration: "4h 30m", minPrice: 18000, maxPrice: 45000, link: "https://www.google.com/flights" }],
    drive: null, bus: null, train: null,
  },
  "DPS-SIN": {
    flight: [{ airline: "Scoot", code: "TR", duration: "2h 35m", minPrice: 9000, maxPrice: 25000, link: "https://www.google.com/flights" }, { airline: "Singapore Airlines", code: "SQ", duration: "2h 30m", minPrice: 14000, maxPrice: 38000, link: "https://www.google.com/flights" }],
    drive: null, bus: null, train: null,
  },
  "NRT-ITM": {
    flight: [{ airline: "ANA", code: "NH", duration: "1h 15m", minPrice: 8000, maxPrice: 22000, link: "https://www.google.com/flights" }],
    train: [{ name: "Shinkansen (Nozomi)", number: "N700", duration: "2h 15m", classes: { "Ordinary": { price: 7000, avail: "Available" }, "Green": { price: 10500, avail: "Available" } }, link: "https://www.irctc.co.in" }],
    drive: { distance: 504, fuelCost: 9000, toll: 4500 },
    bus: [{ operator: "Willer Express", duration: "8 hrs", price: "₹2,200–4,000", link: "https://www.redbus.in" }],
  },
  "ITM-KIX": {
    flight: null,
    train: [{ name: "Limited Express Haruka / Local", number: "Various", duration: "0h 15m", classes: { "Ordinary": { price: 180, avail: "Available" } }, link: "https://www.irctc.co.in" }],
    drive: { distance: 43, fuelCost: 800, toll: 200 },
    bus: [{ operator: "City Bus", duration: "45 min", price: "₹160–280", link: "https://www.redbus.in" }],
  },
  "CDG-LHR": {
    flight: [{ airline: "British Airways", code: "BA", duration: "1h 20m", minPrice: 8000, maxPrice: 28000, link: "https://www.google.com/flights" }],
    train: [{ name: "Eurostar", number: "ES", duration: "2h 15m", classes: { "Standard": { price: 7500, avail: "Available" }, "Standard Premier": { price: 18000, avail: "Moderate" } }, link: "https://www.irctc.co.in" }],
    drive: { distance: 455, fuelCost: 12000, toll: 3500 },
    bus: [{ operator: "Eurolines", duration: "7.5 hrs", price: "₹2,500–5,500", link: "https://www.redbus.in" }],
  },
  "LHR-FCO": {
    flight: [{ airline: "British Airways", code: "BA", duration: "2h 30m", minPrice: 10000, maxPrice: 35000, link: "https://www.google.com/flights" }, { airline: "Ryanair", code: "FR", duration: "2h 40m", minPrice: 5000, maxPrice: 18000, link: "https://www.google.com/flights" }],
    drive: null, bus: null, train: null,
  },
  "DEL-DXB": {
    flight: [{ airline: "Emirates", code: "EK", duration: "3h 25m", minPrice: 18000, maxPrice: 55000, link: "https://www.google.com/flights" }, { airline: "Air Arabia", code: "G9", duration: "3h 30m", minPrice: 12000, maxPrice: 38000, link: "https://www.google.com/flights" }],
    drive: null, bus: null, train: null,
  },
  "DXB-IST": {
    flight: [{ airline: "Emirates", code: "EK", duration: "4h 00m", minPrice: 22000, maxPrice: 68000, link: "https://www.google.com/flights" }, { airline: "flydubai", code: "FZ", duration: "4h 10m", minPrice: 14000, maxPrice: 42000, link: "https://www.google.com/flights" }],
    drive: null, bus: null, train: null,
  },
  "BOM-MLE": {
    flight: [{ airline: "IndiGo", code: "6E", duration: "2h 30m", minPrice: 14000, maxPrice: 45000, link: "https://www.google.com/flights" }, { airline: "Maldivian", code: "Q2", duration: "2h 45m", minPrice: 18000, maxPrice: 55000, link: "https://www.google.com/flights" }],
    drive: null, bus: null, train: null,
  },
  "MLE-GOI": {
    flight: [{ airline: "IndiGo", code: "6E", duration: "3h 00m", minPrice: 12000, maxPrice: 38000, link: "https://www.google.com/flights" }],
    drive: null, bus: null, train: null,
  },
};

export const getTransportRoute = (fromIata, toIata) => {
  const key1 = `${fromIata}-${toIata}`;
  const key2 = `${toIata}-${fromIata}`;
  return transportRoutes[key1] || transportRoutes[key2] || null;
};

export const localTransport = {
  "New Delhi": [
    { type: "Metro", icon: "🚇", name: "Delhi Metro", fare: "₹10–60", coverage: "Extensive network covering all major areas, 390 km" },
    { type: "Bus", icon: "🚌", name: "DTC/Cluster Bus", fare: "₹10–25", coverage: "City-wide, frequent on major routes" },
    { type: "Auto", icon: "🛺", name: "Auto-Rickshaw", fare: "₹25 base + ₹8.5/km", coverage: "Citywide, use Rapido or Ola apps for metered" },
    { type: "Taxi", icon: "🚕", name: "Ola/Uber", fare: "₹70–400", coverage: "Citywide, reliable booking apps" },
  ],
  "Mumbai": [
    { type: "Train", icon: "🚆", name: "Mumbai Local Train", fare: "₹10–100", coverage: "Western, Central, and Harbour lines — the city's lifeline" },
    { type: "Metro", icon: "🚇", name: "Mumbai Metro", fare: "₹10–40", coverage: "Line 1, 2A, 7 and expanding; major corridors" },
    { type: "Bus", icon: "🚌", name: "BEST Bus", fare: "₹5–20", coverage: "Extensive city bus network" },
    { type: "Auto", icon: "🛺", name: "Auto-Rickshaw", fare: "₹21 base + ₹14.11/km", coverage: "Suburban areas (not South Mumbai)" },
  ],
  "Singapore": [
    { type: "MRT", icon: "🚇", name: "Mass Rapid Transit", fare: "S$0.90–2.50 (₹56–156)", coverage: "6 lines covering entire island, 130 stations" },
    { type: "Bus", icon: "🚌", name: "SBS/SMRT Bus", fare: "S$0.77–2.20 (₹48–138)", coverage: "Comprehensive network, exactly on schedule" },
    { type: "Taxi", icon: "🚕", name: "Grab/Gojek", fare: "S$5–25 (₹313–1,563)", coverage: "Citywide, safe and reliable" },
  ],
  "Bangkok": [
    { type: "BTS", icon: "🚈", name: "BTS Skytrain", fare: "฿17–62 (₹39–143)", coverage: "Sukhumvit and Silom lines; central Bangkok" },
    { type: "MRT", icon: "🚇", name: "MRT Subway", fare: "฿17–42 (₹39–97)", coverage: "Blue, Purple, Yellow, Orange lines" },
    { type: "Boat", icon: "⛵", name: "Chao Phraya River Boat", fare: "฿15–30 (₹35–69)", coverage: "Riverside attractions, most historic sites" },
    { type: "Tuk-tuk", icon: "🛺", name: "Tuk-tuk", fare: "฿60–200 (₹138–460)", coverage: "Short distances; negotiate price before boarding" },
    { type: "Grab", icon: "🚕", name: "Grab", fare: "฿50–200 (₹115–460)", coverage: "Entire city, meter taxi equivalent" },
  ],
  "Tokyo": [
    { type: "Metro", icon: "🚇", name: "Tokyo Metro", fare: "¥170–320 (₹94–176)", coverage: "13 lines, 285 stations, most of the city" },
    { type: "JR", icon: "🚆", name: "JR Yamanote Line", fare: "¥140–200 (₹77–110)", coverage: "Loop around central Tokyo's major areas" },
    { type: "Bus", icon: "🚌", name: "Toei Bus", fare: "¥210 (₹116) flat", coverage: "Areas not served by metro" },
    { type: "Taxi", icon: "🚕", name: "Taxi", fare: "¥730 base (₹402) + metered", coverage: "Citywide; expensive but clean and safe" },
  ],
  "Dubai": [
    { type: "Metro", icon: "🚇", name: "Dubai Metro", fare: "AED 3–9.5 (₹68–216)", coverage: "Red and Green lines; mall and business districts" },
    { type: "Bus", icon: "🚌", name: "RTA Bus", fare: "AED 2–10 (₹45–227)", coverage: "Air-conditioned; covers most of the city" },
    { type: "Taxi", icon: "🚕", name: "Taxi/Careem", fare: "AED 12 base (₹272) + metered", coverage: "Citywide, reliable metered taxis" },
    { type: "Tram", icon: "🚋", name: "Dubai Tram", fare: "AED 3 (₹68)", coverage: "Al Sufouh area, connects to Palm Monorail" },
  ],
  "Istanbul": [
    { type: "Metro", icon: "🚇", name: "Istanbul Metro (M-lines)", fare: "₺8.50/₹22", coverage: "M1–M12 lines; airport to city center" },
    { type: "Tram", icon: "🚋", name: "Tram (T1)", fare: "₺8.50/₹22", coverage: "Sultanahmet to Kabataş — all major historical sights" },
    { type: "Ferry", icon: "⛴️", name: "Şehir Hatları Ferry", fare: "₺25/₹64", coverage: "Bosphorus crossings, Asian–European side" },
    { type: "Taxi", icon: "🚕", name: "Taxi", fare: "₺50 base/₹128 + metered", coverage: "Citywide; use BiTaksi app for metered fare" },
  ],
  "Paris": [
    { type: "Metro", icon: "🚇", name: "Paris Métro", fare: "€2.15 (₹197)", coverage: "16 lines, 302 stations — comprehensive coverage" },
    { type: "RER", icon: "🚆", name: "RER", fare: "€2.15–15+ (₹197–1,373)", coverage: "High-speed suburban lines; CDG airport, Versailles" },
    { type: "Bus", icon: "🚌", name: "RATP Bus", fare: "€2.15 (₹197)", coverage: "Extensive; good for scenic routes along Seine" },
    { type: "Taxi", icon: "🚕", name: "Taxi/Uber", fare: "€7.30 base (₹668) + metered", coverage: "Citywide; apps reliable at night" },
  ],
  "London": [
    { type: "Tube", icon: "🚇", name: "London Underground", fare: "£2.80–6.70 (₹298–714)", coverage: "11 lines, 272 stations — the world's first metro" },
    { type: "Bus", icon: "🚌", name: "TfL Red Bus", fare: "£1.75 (₹186)", coverage: "Extensive network, night buses available" },
    { type: "Rail", icon: "🚆", name: "Overground/Elizabeth Line", fare: "£2.80–6.70 (₹298–714)", coverage: "Outer suburbs and Heathrow via Elizabeth Line" },
    { type: "Taxi", icon: "🚕", name: "Black Cab/Uber", fare: "£3.80 base (₹405) + metered", coverage: "Citywide; black cabs hailable anywhere" },
  ],
  "Rome": [
    { type: "Metro", icon: "🚇", name: "Rome Metro", fare: "€1.50 (₹137)", coverage: "Line A and B; key tourist sites" },
    { type: "Bus", icon: "🚌", name: "ATAC Bus", fare: "€1.50 (₹137)", coverage: "Comprehensive; reaches areas metro doesn't" },
    { type: "Tram", icon: "🚋", name: "Tram", fare: "€1.50 (₹137)", coverage: "Lines 2, 3, 8 — Trastevere, Termini, MAXXI" },
    { type: "Taxi", icon: "🚕", name: "Taxi", fare: "€3.50 base (₹320) + metered", coverage: "Citywide; only take licensed white taxis" },
  ],
  "New York": [
    { type: "Subway", icon: "🚇", name: "NYC Subway", fare: "$2.90 (₹242)", coverage: "24/7 service on 36 lines, 472 stations — entire city" },
    { type: "Bus", icon: "🚌", name: "MTA Bus", fare: "$2.90 (₹242)", coverage: "Citywide; useful for crosstown routes" },
    { type: "Taxi", icon: "🚕", name: "Yellow Cab/Lyft/Uber", fare: "$3.50 base (₹292) + metered", coverage: "Citywide; Outer boroughs need app-based rideshare" },
    { type: "Ferry", icon: "⛴️", name: "NYC Ferry", fare: "$4/₹334", coverage: "East River, St. George, South Brooklyn routes" },
  ],
  "Sydney": [
    { type: "Train", icon: "🚆", name: "Sydney Trains", fare: "A$2.20–8.90 (₹120–485)", coverage: "T1–T9 lines; city circle and outer suburbs" },
    { type: "Bus", icon: "🚌", name: "Sydney Buses", fare: "A$2.10–4.60 (₹114–251)", coverage: "Extensive; only way to reach some beaches" },
    { type: "Ferry", icon: "⛴️", name: "Sydney Ferries", fare: "A$6.20 (₹338)", coverage: "Harbour routes; Manly, Taronga Zoo, Parramatta" },
    { type: "Light Rail", icon: "🚋", name: "Light Rail", fare: "A$2.10–4.60 (₹114–251)", coverage: "City to Eastern Suburbs, Olympic Park" },
    { type: "Taxi", icon: "🚕", name: "Taxi/Uber", fare: "A$4.20 base (₹229) + metered", coverage: "Citywide" },
  ],
};

export const getLocalTransport = (city) => localTransport[city] || [
  { type: "Taxi", icon: "🚕", name: "Taxi/Rideshare", fare: "Varies", coverage: "Citywide" },
  { type: "Bus", icon: "🚌", name: "City Bus", fare: "Varies", coverage: "Major routes" },
];

export const getArrivalTransport = (city, country) => {
  const routes = {
    "New Delhi": [
      { from: "Mumbai", mode: "flight", duration: "2h 15m", fare: "₹3,500–12,000" },
      { from: "London", mode: "flight", duration: "8h 45m", fare: "₹38,000–95,000" },
      { from: "Dubai", mode: "flight", duration: "3h 20m", fare: "₹15,000–48,000" },
    ],
    "Singapore": [
      { from: "Mumbai", mode: "flight", duration: "5h 40m", fare: "₹18,000–65,000" },
      { from: "Bangkok", mode: "flight", duration: "2h 25m", fare: "₹8,000–25,000" },
      { from: "Kuala Lumpur", mode: "flight", duration: "1h 00m", fare: "₹5,000–18,000" },
    ],
    "Tokyo": [
      { from: "Delhi", mode: "flight", duration: "8h 30m", fare: "₹32,000–95,000" },
      { from: "Singapore", mode: "flight", duration: "7h 00m", fare: "₹25,000–75,000" },
      { from: "Seoul", mode: "flight", duration: "2h 30m", fare: "₹12,000–35,000" },
    ],
    "Dubai": [
      { from: "Delhi", mode: "flight", duration: "3h 20m", fare: "₹12,000–45,000" },
      { from: "Mumbai", mode: "flight", duration: "3h 00m", fare: "₹10,000–38,000" },
      { from: "London", mode: "flight", duration: "7h 00m", fare: "₹28,000–85,000" },
    ],
  };
  return routes[city] || [
    { from: "Major hub city", mode: "flight", duration: "Varies", fare: "Varies by origin" },
  ];
};
