import React, { useRef, useState } from 'react';
import { useTripContext } from '../context/TripContext';
import { Link, useNavigate } from 'react-router-dom';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import { Share2, Download, Save, Plane, Map, ArrowRight, Brain } from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

// Fix leaflet default icon
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1/dist/images/marker-shadow.png',
});

const createColoredIcon = (color, label) => L.divIcon({
  className: '',
  html: `<div style="width:28px;height:28px;border-radius:50%;background:${color};border:3px solid white;display:flex;align-items:center;justify-content:center;color:white;font-size:11px;font-weight:bold;box-shadow:0 2px 8px rgba(0,0,0,0.5)">${label}</div>`,
  iconSize: [28, 28],
  iconAnchor: [14, 14],
  popupAnchor: [0, -14],
});

const MapBounds = ({ cities }) => {
  const map = useMap();
  React.useEffect(() => {
    if (cities.length > 0) {
      const bounds = L.latLngBounds(cities.map(c => [c.lat, c.lon]));
      if (cities.length === 1) {
        map.setView([cities[0].lat, cities[0].lon], 8);
      } else {
        map.fitBounds(bounds, { padding: [40, 40] });
      }
    }
  }, [cities, map]);
  return null;
};

const TRANSPORT_EMOJI = { Flight: '✈️', Train: '🚆', Bus: '🚌', Drive: '🚗', Ferry: '⛴️' };

export default function MapView() {
  const { tripCities, currentItinerary, generateItinerary, saveCurrentTrip } = useTripContext();
  const navigate = useNavigate();
  const timelineRef = useRef();
  const [exporting, setExporting] = useState(false);

  const cities = tripCities.filter(c => c.lat && c.lon);
  const positions = cities.map(c => [c.lat, c.lon]);

  const getMarkerColor = (idx) => {
    if (idx === 0) return '#4ade80';
    if (idx === cities.length - 1) return '#f87171';
    return '#6366f1';
  };

  const handleShare = () => {
    const itinerary = currentItinerary || generateItinerary();
    if (!itinerary) return;
    const encoded = btoa(JSON.stringify({ code: itinerary.code, name: itinerary.name, cities: tripCities.map(c => c.iata) }));
    const url = `${window.location.origin}/planner?trip=${encoded}`;
    navigator.clipboard?.writeText(url);
    alert('Share link copied to clipboard!');
  };

  const handleExportPDF = async () => {
    if (!timelineRef.current) return;
    setExporting(true);
    try {
      const canvas = await html2canvas(timelineRef.current, { backgroundColor: '#07080f', scale: 2 });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

      const title = currentItinerary?.name || 'My Trip';
      const code = currentItinerary?.code || '';
      pdf.setFontSize(24);
      pdf.setTextColor(99, 102, 241);
      pdf.text('TripFlow', 20, 20);
      pdf.setFontSize(18);
      pdf.setTextColor(226, 232, 240);
      pdf.text(title, 20, 32);
      if (code) {
        pdf.setFontSize(10);
        pdf.setTextColor(150, 150, 180);
        pdf.text(`Trip Code: ${code}`, 20, 40);
      }

      const route = tripCities.map(c => c.city).join(' → ');
      pdf.setFontSize(10);
      pdf.setTextColor(148, 163, 184);
      pdf.text(`Route: ${route}`, 20, 50);
      pdf.text(`Cities: ${tripCities.length} | Total Nights: ${tripCities.reduce((s, c) => s + (c.nights || 0), 0)}`, 20, 58);

      const imgWidth = 170;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      pdf.addImage(imgData, 'PNG', 20, 70, imgWidth, imgHeight);

      pdf.save(`${title.replace(/\s+/g, '_')}_TripFlow.pdf`);
    } catch (err) {
      console.error('PDF export failed:', err);
    }
    setExporting(false);
  };

  const handleSave = () => {
    generateItinerary();
    setTimeout(saveCurrentTrip, 100);
    alert('Trip saved!');
  };

  if (tripCities.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 pt-28 pb-12 text-center">
        <Map size={64} className="text-slate-600 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-slate-100 mb-2">No itinerary to map</h2>
        <p className="text-slate-400 mb-6">Add cities in the planner to see your route on the map.</p>
        <Link to="/planner" className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-3 rounded-xl font-semibold transition-all">
          Go to Planner <ArrowRight size={16} />
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 pt-20 pb-12 animate-fade-in">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">Trip Map</h1>
          <p className="text-slate-400 text-sm">{currentItinerary?.name || 'Your Itinerary'} · {tripCities.length} cities · {tripCities.reduce((s, c) => s + (c.nights || 0), 0)} nights</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={handleShare} className="flex items-center gap-2 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-300 px-4 py-2 rounded-xl text-sm font-medium transition-all">
            <Share2 size={15} /> Share
          </button>
          <button onClick={handleExportPDF} disabled={exporting} className="flex items-center gap-2 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400 px-4 py-2 rounded-xl text-sm font-medium transition-all">
            <Download size={15} /> {exporting ? 'Exporting...' : 'Export PDF'}
          </button>
          <button onClick={handleSave} className="flex items-center gap-2 bg-green-500/20 hover:bg-green-500/30 text-green-400 px-4 py-2 rounded-xl text-sm font-medium transition-all">
            <Save size={15} /> Save Trip
          </button>
          <Link to="/intelligence" className="flex items-center gap-2 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 px-4 py-2 rounded-xl text-sm font-medium transition-all">
            <Brain size={15} /> Intelligence
          </Link>
        </div>
      </div>

      {/* Map */}
      <div className="h-[450px] rounded-2xl overflow-hidden border border-white/5 mb-6">
        <MapContainer center={[20, 80]} zoom={4} style={{ height: '100%', width: '100%' }} className="z-10">
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          />
          {cities.length > 0 && <MapBounds cities={cities} />}
          {cities.length > 1 && (
            <Polyline
              positions={positions}
              pathOptions={{ color: '#6366f1', weight: 2, opacity: 0.7, dashArray: '8 6' }}
            />
          )}
          {cities.map((city, idx) => (
            <Marker key={city.iata} position={[city.lat, city.lon]} icon={createColoredIcon(getMarkerColor(idx), idx + 1)}>
              <Popup>
                <div style={{ color: '#e2e8f0', fontFamily: 'Cabinet Grotesk, sans-serif', minWidth: '160px' }}>
                  <div style={{ fontSize: '18px', marginBottom: '4px' }}>{city.emoji} <strong>{city.city}</strong></div>
                  <div style={{ color: '#94a3b8', fontSize: '12px' }}>{city.country}</div>
                  {city.arrival && <div style={{ fontSize: '12px', marginTop: '6px', color: '#a5b4fc' }}>📅 {city.arrival} → {city.departure || '?'}</div>}
                  <div style={{ fontSize: '12px', color: '#94a3b8' }}>🌙 {city.nights || 0} nights</div>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>

      {/* Timeline */}
      <div ref={timelineRef} className="bg-card border border-white/5 rounded-2xl p-6">
        <h2 className="font-bold text-slate-100 mb-5 flex items-center gap-2"><Plane size={16} className="text-indigo-400" /> Itinerary Timeline</h2>
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-5 top-0 bottom-0 w-0.5 bg-white/10" />
          <div className="space-y-6">
            {tripCities.map((city, idx) => {
              const isFirst = idx === 0;
              const isLast = idx === tripCities.length - 1;
              const nodeColor = isFirst ? '#4ade80' : isLast ? '#f87171' : '#6366f1';
              const nextCity = tripCities[idx + 1];
              const legCost = nextCity ? Math.round(8500 + Math.random() * 5000) : 0;

              return (
                <div key={city.iata} className="relative pl-14">
                  {/* Node */}
                  <div className="absolute left-3 top-0 w-5 h-5 rounded-full border-2 border-white/20 flex items-center justify-center text-xs font-bold" style={{ backgroundColor: nodeColor + '30', borderColor: nodeColor, color: nodeColor }}>
                    {idx + 1}
                  </div>
                  <div className="flex items-start justify-between flex-wrap gap-3">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{city.emoji}</span>
                      <div>
                        <h3 className="font-semibold text-slate-100">{city.city}</h3>
                        <p className="text-xs text-slate-500">{city.country} · {city.iata}</p>
                        {city.arrival && (
                          <p className="text-xs text-slate-400 mt-1">
                            {city.arrival} → {city.departure || '?'} · {city.nights || 0} nights
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {city.transportMode && idx > 0 && (
                        <span className="text-xs bg-indigo-600/10 text-indigo-400 border border-indigo-500/20 px-2 py-1 rounded-lg">
                          {TRANSPORT_EMOJI[city.transportMode] || '✈️'} {city.transportMode}
                        </span>
                      )}
                    </div>
                  </div>
                  {nextCity && (
                    <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
                      <ArrowRight size={12} />
                      <span>Next: {nextCity.city}</span>
                      {city.transportMode && <span className="text-indigo-400 font-medium">· Est. ₹{legCost.toLocaleString()}</span>}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
