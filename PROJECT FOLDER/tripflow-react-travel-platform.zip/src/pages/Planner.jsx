import React, { useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTripContext } from '../context/TripContext';
import { searchAirports } from '../data/airports';
import { weatherData } from '../data/weatherData';
import { addDays, format, differenceInDays, parseISO } from 'date-fns';
import { Copy, RefreshCw, Search, X, ChevronUp, ChevronDown, Map, Save, Trash2, Plus, Check, AlertCircle, Clock, Info, GripVertical, Plane, Train, Car, Ship, Bus } from 'lucide-react';

const NATIONALITIES = ['Indian', 'American', 'British', 'Australian', 'Canadian', 'German', 'French', 'Japanese', 'Singaporean', 'Emirati'];
const TRAVELER_TYPES = ['Solo', 'Couple', 'Family', 'Group'];
const TRANSPORT_MODES = [
  { id: 'Flight', icon: Plane, emoji: '✈️' },
  { id: 'Train', icon: Train, emoji: '🚆' },
  { id: 'Bus', icon: Bus, emoji: '🚌' },
  { id: 'Drive', icon: Car, emoji: '🚗' },
  { id: 'Ferry', icon: Ship, emoji: '⛴️' },
];

const PACKING_ITEMS = [
  'Passport & visa documents', 'Travel insurance certificate', 'International power adapter',
  'Portable phone charger', 'Universal SIM card', 'Medications & first aid kit',
  'Sunscreen SPF 50+', 'Insect repellent', 'Comfortable walking shoes',
  'Lightweight rain jacket', 'Packable day bag', 'Reusable water bottle',
  'Camera & memory cards', 'Copies of all documents (cloud backup)', 'Local currency (cash)',
  'Credit/debit cards (notify bank)', 'Travel towel', 'Earplugs & eye mask',
  'Locks for luggage', 'Emergency contact list', 'Phrasebook or translation app',
  'Snacks for long journeys', 'Face masks', 'Hand sanitizer',
];

const BEACH_ITEMS = ['Swimwear', 'Beach towel', 'Water shoes', 'Snorkeling gear'];
const WINTER_ITEMS = ['Thermal underlayer', 'Heavy winter coat', 'Gloves and scarf', 'Snow boots'];

const getConnectionStatus = (departure, nextArrival) => {
  if (!departure || !nextArrival) return null;
  try {
    const dep = parseISO(departure);
    const arr = parseISO(nextArrival);
    const diff = differenceInDays(arr, dep);
    if (diff < 0) return { status: 'error', label: 'Invalid — arrival before departure', color: 'text-red-400' };
    if (diff === 0) return { status: 'tight', label: 'Same-day connection — check timing', color: 'text-yellow-400' };
    if (diff === 1) return { status: 'good', label: 'Good connection', color: 'text-green-400' };
    if (diff <= 3) return { status: 'layover', label: `Long layover — ${diff} days gap`, color: 'text-yellow-400' };
    return { status: 'ok', label: `${diff} days gap`, color: 'text-slate-400' };
  } catch { return null; }
};

const estimateBudget = (cities, nights) => {
  const transportCostPerLeg = 8500;
  const accommodationPerNight = 3500;
  const foodPerNight = 1500;
  const activities = 1200;
  const transport = Math.max(0, cities.length - 1) * transportCostPerLeg;
  const accommodation = nights * accommodationPerNight;
  const food = nights * foodPerNight;
  const act = nights * activities;
  return { transport, accommodation, food, activities: act, total: transport + accommodation + food + act };
};

export default function Planner() {
  const {
    tripCities, addCity, removeCity, updateCity, reorderCities,
    tripName, setTripName, tripCode, regenerateTripCode,
    nationality, setNationality, travelerType, setTravelerType,
    generateItinerary, saveCurrentTrip, clearTrip,
    checkedPackingItems, togglePackingItem, currentItinerary,
  } = useTripContext();
  const navigate = useNavigate();

  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [copied, setCopied] = useState(false);
  const [showPacking, setShowPacking] = useState(true);
  const [dragIdx, setDragIdx] = useState(null);
  const [dragOverIdx, setDragOverIdx] = useState(null);
  const searchRef = useRef(null);

  const totalNights = tripCities.reduce((s, c) => s + (c.nights || 0), 0);
  const budget = estimateBudget(tripCities, totalNights);

  const hasBothBeachAndWinter = () => {
    const tags = tripCities.map(c => c.tag?.toLowerCase() || '');
    return { beach: tags.some(t => t.includes('beach')), winter: tags.some(t => t.includes('winter') || t.includes('snow')) };
  };
  const { beach, winter } = hasBothBeachAndWinter();

  const packingList = [...PACKING_ITEMS, ...(beach ? BEACH_ITEMS : []), ...(winter ? WINTER_ITEMS : [])].slice(0, 24);

  const handleSearch = (e) => {
    const q = e.target.value;
    setQuery(q);
    if (q.length > 1) setSuggestions(searchAirports(q).slice(0, 8));
    else setSuggestions([]);
  };

  const handleSelectCity = (airport) => {
    addCity(airport);
    setQuery('');
    setSuggestions([]);
  };

  const handleCopyCode = () => {
    navigator.clipboard?.writeText(tripCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleNightsChange = (iata, delta) => {
    const city = tripCities.find(c => c.iata === iata);
    if (!city) return;
    const newNights = Math.max(1, (city.nights || 1) + delta);
    updateCity(iata, { nights: newNights });
    // Update departure date if arrival is set
    if (city.arrival) {
      const dep = format(addDays(parseISO(city.arrival), newNights), 'yyyy-MM-dd');
      updateCity(iata, { nights: newNights, departure: dep });
    }
  };

  const handleArrivalChange = (iata, arrival) => {
    const city = tripCities.find(c => c.iata === iata);
    if (!city) return;
    const dep = arrival ? format(addDays(parseISO(arrival), city.nights || 3), 'yyyy-MM-dd') : '';
    updateCity(iata, { arrival, departure: dep });
  };

  const handleGenerate = () => {
    if (tripCities.length === 0) return;
    generateItinerary();
    navigate('/map');
  };

  const handleSave = () => {
    if (tripCities.length === 0) return;
    generateItinerary();
    setTimeout(saveCurrentTrip, 100);
    alert('Trip saved!');
  };

  // Drag reorder
  const handleDragStart = (idx) => setDragIdx(idx);
  const handleDragOver = (e, idx) => { e.preventDefault(); setDragOverIdx(idx); };
  const handleDrop = (idx) => {
    if (dragIdx !== null && dragIdx !== idx) reorderCities(dragIdx, idx);
    setDragIdx(null);
    setDragOverIdx(null);
  };

  // Best months aggregation
  const bestMonths = [...new Set(
    tripCities.flatMap(c => {
      const w = weatherData[c.city];
      return w ? w.bestMonths : [];
    })
  )].slice(0, 4);

  const routeString = tripCities.map(c => c.city).join(' → ');

  return (
    <div className="max-w-7xl mx-auto px-4 pt-24 pb-12 animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-100">Trip Planner</h1>
        <p className="text-slate-400 text-sm mt-1">Build your perfect itinerary step by step</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* LEFT PANEL */}
        <div className="lg:col-span-2 space-y-4">
          {/* Build card */}
          <div className="bg-card border border-white/5 rounded-2xl p-5">
            <h2 className="font-bold text-slate-100 mb-4 flex items-center gap-2"><Plus size={16} className="text-indigo-400" /> Build Your Trip</h2>

            {/* Trip name + code */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">Trip Name *</label>
                <input
                  type="text"
                  value={tripName}
                  onChange={e => setTripName(e.target.value)}
                  placeholder="My Dream Trip"
                  className="w-full bg-surface border border-white/10 rounded-xl px-3 py-2.5 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">Trip Code</label>
                <div className="flex gap-2">
                  <div className="flex-1 bg-surface border border-white/10 rounded-xl px-3 py-2.5 font-mono text-sm text-indigo-400 flex items-center justify-between">
                    {tripCode}
                    <button onClick={handleCopyCode} className="text-slate-500 hover:text-slate-300 transition-colors ml-2">
                      {copied ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                    </button>
                  </div>
                  <button onClick={regenerateTripCode} className="p-2.5 bg-surface border border-white/10 rounded-xl text-slate-400 hover:text-slate-200 transition-colors">
                    <RefreshCw size={14} />
                  </button>
                </div>
              </div>
            </div>

            {/* Nationality + Traveler type */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">Nationality</label>
                <select value={nationality} onChange={e => setNationality(e.target.value)} className="w-full bg-surface border border-white/10 rounded-xl px-3 py-2.5 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors">
                  {NATIONALITIES.map(n => <option key={n} value={n}>{n}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">Traveler Type</label>
                <div className="flex gap-1.5 flex-wrap">
                  {TRAVELER_TYPES.map(t => (
                    <button key={t} onClick={() => setTravelerType(t)} className={`pill-btn text-xs ${travelerType === t ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-surface text-slate-400 border-white/10 hover:text-slate-200'}`}>
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* City Search */}
            <div className="relative mb-4">
              <label className="block text-xs text-slate-400 mb-1.5">Add Cities</label>
              <div className="relative">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  ref={searchRef}
                  type="text"
                  value={query}
                  onChange={handleSearch}
                  placeholder="Search city, country, or IATA code..."
                  className="w-full bg-surface border border-white/10 rounded-xl pl-9 pr-4 py-2.5 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                />
                {query && (
                  <button onClick={() => { setQuery(''); setSuggestions([]); }} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300">
                    <X size={14} />
                  </button>
                )}
              </div>
              {suggestions.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-surface border border-white/10 rounded-xl shadow-2xl z-50 overflow-hidden">
                  {suggestions.map(a => (
                    <button key={a.iata} onClick={() => handleSelectCity(a)} className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-white/5 transition-colors text-left">
                      <span className="text-xl">{a.emoji}</span>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-slate-200">{a.city}</div>
                        <div className="text-xs text-slate-500">{a.country} · {a.iata}</div>
                      </div>
                      <span className="text-xs bg-indigo-600/20 text-indigo-400 px-2 py-0.5 rounded-full">{a.tag}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* City Cards */}
            {tripCities.length === 0 ? (
              <div className="border border-dashed border-white/10 rounded-xl p-8 text-center">
                <Search size={32} className="text-slate-600 mx-auto mb-2" />
                <p className="text-slate-400 text-sm">Search for cities to start building your itinerary</p>
              </div>
            ) : (
              <div className="space-y-3">
                {tripCities.map((city, idx) => {
                  const isFirst = idx === 0;
                  const isLast = idx === tripCities.length - 1;
                  const nextCity = tripCities[idx + 1];
                  const connStatus = nextCity ? getConnectionStatus(city.departure, nextCity.arrival) : null;
                  const badgeColor = isFirst ? 'bg-green-500/20 text-green-400 border-green-500/30' : isLast ? 'bg-red-500/20 text-red-400 border-red-500/30' : 'bg-indigo-600/20 text-indigo-400 border-indigo-500/30';

                  return (
                    <div key={city.id || city.iata} className={`bg-surface border rounded-xl p-4 transition-all ${dragOverIdx === idx ? 'border-indigo-500/50 bg-indigo-600/5' : 'border-white/5'}`}
                      draggable onDragStart={() => handleDragStart(idx)} onDragOver={e => handleDragOver(e, idx)} onDrop={() => handleDrop(idx)}>
                      <div className="flex items-center gap-3 mb-3">
                        <div className="cursor-grab text-slate-600 hover:text-slate-400">
                          <GripVertical size={14} />
                        </div>
                        <span className={`w-6 h-6 rounded-full border text-xs font-bold flex items-center justify-center ${badgeColor}`}>{idx + 1}</span>
                        <span className="text-lg">{city.emoji}</span>
                        <div className="flex-1">
                          <div className="font-semibold text-slate-100 text-sm">{city.city}</div>
                          <div className="text-xs text-slate-500">{city.iata} · {city.country}</div>
                        </div>
                        <button onClick={() => removeCity(city.iata)} className="text-slate-600 hover:text-red-400 transition-colors p-1">
                          <X size={14} />
                        </button>
                      </div>

                      {/* Transport mode (not first) */}
                      {idx > 0 && (
                        <div className="mb-3">
                          <label className="text-xs text-slate-500 mb-1.5 block">Transport from previous city</label>
                          <div className="flex gap-1.5 flex-wrap">
                            {TRANSPORT_MODES.map(m => (
                              <button key={m.id} onClick={() => updateCity(city.iata, { transportMode: m.id })} className={`flex items-center gap-1 text-xs px-2.5 py-1.5 rounded-lg border transition-all ${city.transportMode === m.id ? 'bg-indigo-600/20 border-indigo-500/40 text-indigo-300' : 'bg-card border-white/10 text-slate-400 hover:text-slate-200'}`}>
                                {m.emoji} {m.id}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Dates + Nights */}
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        <div>
                          <label className="text-xs text-slate-500 mb-1 block">Arrival</label>
                          <input type="date" value={city.arrival || ''} onChange={e => handleArrivalChange(city.iata, e.target.value)} className="w-full bg-card border border-white/10 rounded-lg px-2 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500" />
                        </div>
                        <div>
                          <label className="text-xs text-slate-500 mb-1 block">Departure</label>
                          <input type="date" value={city.departure || ''} onChange={e => updateCity(city.iata, { departure: e.target.value })} className="w-full bg-card border border-white/10 rounded-lg px-2 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500" />
                        </div>
                        <div>
                          <label className="text-xs text-slate-500 mb-1 block">Nights</label>
                          <div className="flex items-center gap-1">
                            <button onClick={() => handleNightsChange(city.iata, -1)} className="w-7 h-7 rounded-lg bg-card border border-white/10 flex items-center justify-center text-xs hover:bg-white/10 transition-colors">−</button>
                            <span className="flex-1 text-center text-sm text-slate-200 font-medium">{city.nights || 3}</span>
                            <button onClick={() => handleNightsChange(city.iata, 1)} className="w-7 h-7 rounded-lg bg-card border border-white/10 flex items-center justify-center text-xs hover:bg-white/10 transition-colors">+</button>
                          </div>
                        </div>
                      </div>

                      {/* Connection validator */}
                      {connStatus && (
                        <div className={`mt-2 flex items-center gap-1.5 text-xs ${connStatus.color}`}>
                          {connStatus.status === 'good' ? <Check size={12} /> : connStatus.status === 'error' ? <AlertCircle size={12} /> : <Clock size={12} />}
                          {connStatus.label} → {nextCity?.city}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-2 mt-4 flex-wrap">
              <button onClick={handleGenerate} disabled={tripCities.length === 0} className="flex-1 flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white py-2.5 rounded-xl font-semibold transition-all text-sm">
                <Map size={16} /> Generate Itinerary
              </button>
              <button onClick={handleSave} disabled={tripCities.length === 0} className="flex items-center gap-2 bg-green-500/20 hover:bg-green-500/30 text-green-400 px-4 py-2.5 rounded-xl font-semibold transition-all text-sm">
                <Save size={16} /> Save
              </button>
              <button onClick={clearTrip} className="flex items-center gap-2 bg-white/5 hover:bg-white/10 text-slate-400 px-4 py-2.5 rounded-xl font-semibold transition-all text-sm">
                <Trash2 size={16} /> Clear
              </button>
            </div>
          </div>
        </div>

        {/* RIGHT SIDEBAR */}
        <div className="space-y-4">
          {/* Trip Overview */}
          <div className="bg-card border border-white/5 rounded-2xl p-5">
            <h3 className="font-bold text-slate-100 mb-4 text-sm">Trip Overview</h3>
            {tripCities.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-4">Add cities to see your trip summary</p>
            ) : (
              <>
                <div className="text-xs text-slate-400 mb-2">Route</div>
                <div className="text-sm text-slate-200 font-medium mb-4 break-words leading-relaxed">
                  {routeString || '—'}
                </div>
                <div className="space-y-2 mb-4">
                  {[
                    { label: 'Cities', value: tripCities.length },
                    { label: 'Total Nights', value: totalNights },
                  ].map(({ label, value }) => (
                    <div key={label} className="flex justify-between text-xs">
                      <span className="text-slate-400">{label}</span>
                      <span className="text-slate-200 font-medium">{value}</span>
                    </div>
                  ))}
                </div>
                <div className="border-t border-white/5 pt-3 space-y-2">
                  <div className="text-xs text-slate-400 mb-2">Estimated Budget (Mid-range)</div>
                  {[
                    { label: 'Transport', value: budget.transport },
                    { label: 'Accommodation', value: budget.accommodation },
                    { label: 'Food', value: budget.food },
                    { label: 'Activities', value: budget.activities },
                  ].map(({ label, value }) => (
                    <div key={label} className="flex justify-between text-xs">
                      <span className="text-slate-500">{label}</span>
                      <span className="text-slate-300">₹{value.toLocaleString()}</span>
                    </div>
                  ))}
                  <div className="flex justify-between text-sm font-semibold border-t border-white/10 pt-2 mt-2">
                    <span className="text-slate-200">Total Estimate</span>
                    <span className="gradient-text">₹{budget.total.toLocaleString()}</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">* Estimates only. Actual costs may vary.</p>
                </div>
              </>
            )}
          </div>

          {/* Best Travel Months */}
          {bestMonths.length > 0 && (
            <div className="bg-card border border-white/5 rounded-2xl p-5">
              <h3 className="font-bold text-slate-100 mb-3 text-sm flex items-center gap-2">
                <Info size={14} className="text-cyan-400" /> Best Travel Months
              </h3>
              <div className="flex flex-wrap gap-1.5">
                {bestMonths.map(m => (
                  <span key={m} className="text-xs bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2.5 py-1 rounded-full">{m}</span>
                ))}
              </div>
              <p className="text-xs text-slate-500 mt-2">Based on your selected destinations</p>
            </div>
          )}

          {/* Packing List */}
          <div className="bg-card border border-white/5 rounded-2xl p-5">
            <button onClick={() => setShowPacking(!showPacking)} className="w-full flex items-center justify-between text-sm font-bold text-slate-100 mb-3">
              🎒 Smart Packing List
              {showPacking ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
            </button>
            {showPacking && (
              <div className="space-y-2 max-h-64 overflow-y-auto scrollbar-hidden">
                {packingList.map((item, i) => {
                  const key = `packing_${i}`;
                  const checked = checkedPackingItems[key];
                  return (
                    <label key={i} className="flex items-center gap-2.5 cursor-pointer group">
                      <div onClick={() => togglePackingItem(key)} className={`w-4 h-4 rounded border flex items-center justify-center flex-shrink-0 transition-all ${checked ? 'bg-indigo-600 border-indigo-600' : 'border-white/20 group-hover:border-indigo-500/50'}`}>
                        {checked && <Check size={10} className="text-white" />}
                      </div>
                      <span className={`text-xs ${checked ? 'line-through text-slate-600' : 'text-slate-300'}`}>{item}</span>
                    </label>
                  );
                })}
              </div>
            )}
          </div>

          {/* Connection Validator Summary */}
          {tripCities.length > 1 && (
            <div className="bg-card border border-white/5 rounded-2xl p-5">
              <h3 className="font-bold text-slate-100 mb-3 text-sm">Connection Validator</h3>
              <div className="space-y-2">
                {tripCities.slice(0, -1).map((city, idx) => {
                  const next = tripCities[idx + 1];
                  const conn = getConnectionStatus(city.departure, next.arrival);
                  return (
                    <div key={city.iata} className="flex items-center justify-between text-xs">
                      <span className="text-slate-400">{city.city} → {next.city}</span>
                      {conn ? (
                        <span className={conn.color}>{conn.status === 'good' ? '✓ OK' : conn.status === 'error' ? '✗ Error' : '⚠ Check'}</span>
                      ) : (
                        <span className="text-slate-600">No dates</span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
