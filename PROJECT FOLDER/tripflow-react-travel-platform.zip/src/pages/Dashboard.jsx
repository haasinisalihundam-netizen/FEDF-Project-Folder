import React from 'react';
import { Link } from 'react-router-dom';
import { useTripContext } from '../context/TripContext';
import { Plane, Map, Compass, Heart, Globe, Moon, Calendar, Trash2, Upload, Share2, Brain } from 'lucide-react';

export default function Dashboard() {
  const { user, savedTrips, deleteSavedTrip, loadSavedTrip, tripCities, currentItinerary } = useTripContext();

  const totalCities = savedTrips.reduce((acc, t) => acc + (t.cities?.length || 0), 0);
  const totalNights = savedTrips.reduce((acc, t) => acc + (t.totalNights || 0), 0);
  const countries = new Set(savedTrips.flatMap(t => t.cities?.map(c => c.country) || []));

  const stats = [
    { label: 'Trips Saved', value: savedTrips.length, icon: Plane, color: 'text-indigo-400' },
    { label: 'Cities Planned', value: totalCities, icon: Map, color: 'text-cyan-400' },
    { label: 'Countries', value: countries.size, icon: Globe, color: 'text-green-400' },
    { label: 'Nights Planned', value: totalNights, icon: Moon, color: 'text-yellow-400' },
  ];

  const handleShare = (trip) => {
    const encoded = btoa(JSON.stringify({ code: trip.code, name: trip.name, cities: trip.cities?.map(c => c.iata) }));
    const url = `${window.location.origin}/planner?trip=${encoded}`;
    navigator.clipboard?.writeText(url);
    alert('Share link copied to clipboard!');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 pt-24 pb-12 animate-fade-in">
      {/* Welcome */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-100 mb-1">
          Welcome back, <span className="gradient-text">{user?.name?.split(' ')[0] || 'Traveler'}</span>!
        </h1>
        <p className="text-slate-400">Here's an overview of your travel plans.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        {stats.map((s) => (
          <div key={s.label} className="bg-card border border-white/5 rounded-2xl p-5">
            <div className="flex items-center gap-3 mb-2">
              <s.icon size={18} className={s.color} />
              <span className="text-sm text-slate-400">{s.label}</span>
            </div>
            <div className="text-3xl font-bold text-slate-100">{s.value}</div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
        <Link to="/planner" className="bg-gradient-to-br from-indigo-600/20 to-indigo-900/20 border border-indigo-500/20 rounded-2xl p-6 card-hover group">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-indigo-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Plane size={22} className="text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-100">Start New Trip</h3>
              <p className="text-sm text-slate-400">Build your itinerary with the trip planner</p>
            </div>
          </div>
        </Link>
        <Link to="/explore" className="bg-gradient-to-br from-cyan-600/10 to-cyan-900/20 border border-cyan-500/20 rounded-2xl p-6 card-hover group">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-cyan-600/80 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Compass size={22} className="text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-100">Explore Destinations</h3>
              <p className="text-sm text-slate-400">Discover cities and country guides</p>
            </div>
          </div>
        </Link>
        <Link to="/intelligence" className="bg-gradient-to-br from-purple-600/10 to-purple-900/20 border border-purple-500/20 rounded-2xl p-6 card-hover group">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-purple-600/80 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Brain size={22} className="text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-100">Travel Intelligence</h3>
              <p className="text-sm text-slate-400">Visas, transport options, budgets</p>
            </div>
          </div>
        </Link>
      </div>

      {/* Current Trip */}
      {tripCities.length > 0 && (
        <div className="mb-10">
          <h2 className="text-xl font-bold text-slate-100 mb-4 flex items-center gap-2">
            <Plane size={18} className="text-indigo-400" />
            Trip in Progress
          </h2>
          <div className="bg-card border border-indigo-500/20 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <div>
                <span className="font-semibold text-slate-100">Active Trip</span>
                <span className="ml-3 text-sm text-slate-400">{tripCities.length} cities</span>
              </div>
              <Link to="/planner" className="text-sm bg-indigo-600/20 text-indigo-400 hover:bg-indigo-600/30 px-4 py-1.5 rounded-lg transition-colors font-medium">
                Continue editing
              </Link>
            </div>
            <div className="flex gap-2 flex-wrap">
              {tripCities.map((c, i) => (
                <span key={c.iata} className="flex items-center gap-1 text-sm bg-surface border border-white/5 px-3 py-1 rounded-full text-slate-300">
                  <span>{c.emoji}</span>
                  <span>{c.city}</span>
                  {i < tripCities.length - 1 && <span className="text-slate-500">→</span>}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Saved Trips */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Heart size={18} className="text-red-400" />
            Saved Trips
          </h2>
          <Link to="/saved" className="text-sm text-indigo-400 hover:text-indigo-300">View all →</Link>
        </div>

        {savedTrips.length === 0 ? (
          <div className="bg-card border border-white/5 rounded-2xl p-12 text-center">
            <Heart size={40} className="text-slate-600 mx-auto mb-3" />
            <h3 className="font-semibold text-slate-300 mb-1">No saved trips yet</h3>
            <p className="text-sm text-slate-500 mb-4">Build a trip in the planner and save it to see it here.</p>
            <Link to="/planner" className="text-sm bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2 rounded-xl transition-colors inline-block">
              Start Planning
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {savedTrips.slice(0, 6).map((trip) => (
              <div key={trip.id} className="bg-card border border-white/5 rounded-2xl p-5">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-slate-100">{trip.name}</h3>
                    <code className="text-xs text-indigo-400 font-mono">{trip.code}</code>
                  </div>
                  <button onClick={() => deleteSavedTrip(trip.id)} className="text-slate-600 hover:text-red-400 transition-colors p-1">
                    <Trash2 size={14} />
                  </button>
                </div>
                <div className="flex items-center gap-3 text-xs text-slate-400 mb-3">
                  <span><Calendar size={11} className="inline mr-1" />{trip.totalNights || 0} nights</span>
                  <span><Globe size={11} className="inline mr-1" />{trip.cities?.length || 0} cities</span>
                </div>
                <div className="flex gap-1 flex-wrap mb-3">
                  {trip.cities?.slice(0, 4).map(c => (
                    <span key={c.iata} className="text-xs bg-surface border border-white/5 px-2 py-0.5 rounded-full text-slate-400">{c.city}</span>
                  ))}
                  {(trip.cities?.length || 0) > 4 && <span className="text-xs text-slate-500">+{trip.cities.length - 4} more</span>}
                </div>
                <div className="flex gap-2">
                  <button onClick={() => loadSavedTrip(trip)} className="flex-1 text-xs bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400 py-1.5 rounded-lg transition-colors font-medium flex items-center justify-center gap-1">
                    <Upload size={12} /> Load
                  </button>
                  <button onClick={() => handleShare(trip)} className="flex-1 text-xs bg-white/5 hover:bg-white/10 text-slate-400 py-1.5 rounded-lg transition-colors flex items-center justify-center gap-1">
                    <Share2 size={12} /> Share
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
