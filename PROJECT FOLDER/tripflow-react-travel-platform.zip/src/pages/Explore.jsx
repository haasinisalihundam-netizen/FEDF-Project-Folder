import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { airports } from '../data/airports';
import { useTripContext } from '../context/TripContext';
import { Search, Plus, Check, Globe, ChevronDown, ChevronRight } from 'lucide-react';

const regions = ['All', 'Asia', 'Europe', 'Americas', 'Middle East', 'Africa', 'Oceania'];

const BEST_SEASONS = {
  India: 'Oct–Mar', Singapore: 'Feb–Apr', Thailand: 'Nov–Feb',
  Indonesia: 'Apr–Oct', Malaysia: 'Mar–Oct', Vietnam: 'Nov–Apr',
  Japan: 'Mar–May, Oct–Nov', 'South Korea': 'Sep–Nov', China: 'Sep–Oct',
  UAE: 'Nov–Mar', Turkey: 'Apr–Jun, Sep–Oct', France: 'Apr–Jun, Sep',
  UK: 'May–Aug', Italy: 'Apr–Jun, Sep–Oct', Spain: 'Apr–Jun, Sep–Oct',
  USA: 'Sep–Nov, Mar–May', Australia: 'Sep–Nov, Mar–May',
  Egypt: 'Oct–Apr', Morocco: 'Mar–May, Sep–Nov', 'South Africa': 'May–Sep',
  Nepal: 'Oct–Nov, Mar–May', Maldives: 'Nov–Apr', 'Sri Lanka': 'Dec–Mar',
};

const getCountries = (region) => {
  const all = region === 'All' ? airports : airports.filter(a => a.region === region);
  const map = {};
  all.forEach(a => {
    if (!map[a.country]) map[a.country] = { country: a.country, region: a.region, cities: [], flag: a.emoji };
    map[a.country].cities.push(a);
  });
  return Object.values(map).sort((a, b) => a.country.localeCompare(b.country));
};

const FLAG_EMOJIS = {
  India: '🇮🇳', Singapore: '🇸🇬', Thailand: '🇹🇭', Indonesia: '🇮🇩', Malaysia: '🇲🇾',
  Vietnam: '🇻🇳', Cambodia: '🇰🇭', Myanmar: '🇲🇲', Philippines: '🇵🇭', Japan: '🇯🇵',
  'South Korea': '🇰🇷', China: '🇨🇳', 'Hong Kong': '🇭🇰', UAE: '🇦🇪', Qatar: '🇶🇦',
  Turkey: '🇹🇷', Jordan: '🇯🇴', France: '🇫🇷', UK: '🇬🇧', Italy: '🇮🇹',
  Spain: '🇪🇸', Netherlands: '🇳🇱', 'Czech Republic': '🇨🇿', Austria: '🇦🇹',
  Greece: '🇬🇷', Switzerland: '🇨🇭', Portugal: '🇵🇹', Ireland: '🇮🇪',
  Denmark: '🇩🇰', Sweden: '🇸🇪', Finland: '🇫🇮', Poland: '🇵🇱', Hungary: '🇭🇺',
  USA: '🇺🇸', Mexico: '🇲🇽', Brazil: '🇧🇷', Peru: '🇵🇪', Colombia: '🇨🇴',
  Canada: '🇨🇦', Argentina: '🇦🇷', Chile: '🇨🇱', Egypt: '🇪🇬',
  'South Africa': '🇿🇦', Kenya: '🇰🇪', Tunisia: '🇹🇳', Morocco: '🇲🇦',
  Australia: '🇦🇺', 'New Zealand': '🇳🇿', Fiji: '🇫🇯', 'Sri Lanka': '🇱🇰',
  Maldives: '🇲🇻', Nepal: '🇳🇵', Bangladesh: '🇧🇩', Israel: '🇮🇱',
  Lebanon: '🇱🇧', Oman: '🇴🇲', 'Saudi Arabia': '🇸🇦',
};

export default function Explore() {
  const [region, setRegion] = useState('All');
  const [query, setQuery] = useState('');
  const [expanded, setExpanded] = useState({});
  const [nightCounts, setNightCounts] = useState({});
  const { addCity, tripCities } = useTripContext();
  const navigate = useNavigate();

  const countries = getCountries(region);
  const filtered = query
    ? countries.filter(c => c.country.toLowerCase().includes(query.toLowerCase()) || c.cities.some(ci => ci.city.toLowerCase().includes(query.toLowerCase())))
    : countries;

  const toggleExpand = (country) => setExpanded(prev => ({ ...prev, [country]: !prev[country] }));

  const handleAddCity = (airport) => {
    const nights = nightCounts[airport.iata] || 3;
    addCity({ ...airport, nights });
    navigate('/planner');
  };

  const adjustNights = (iata, delta) => {
    setNightCounts(prev => ({ ...prev, [iata]: Math.max(1, Math.min(30, (prev[iata] || 3) + delta)) }));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 pt-24 pb-12 animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-100 mb-1">Country Explorer</h1>
        <p className="text-slate-400">Discover destinations by region and country</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search country or city..."
            className="w-full bg-card border border-white/5 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {regions.map(r => (
            <button key={r} onClick={() => setRegion(r)} className={`pill-btn text-xs ${region === r ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-card text-slate-400 border-white/10 hover:text-slate-200'}`}>
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Country Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(({ country, region: reg, cities }) => {
          const isExpanded = expanded[country];
          const flag = FLAG_EMOJIS[country] || '🌍';
          const bestSeason = BEST_SEASONS[country] || 'Year-round';

          return (
            <div key={country} className="bg-card border border-white/5 rounded-2xl overflow-hidden card-hover">
              <div
                className="p-4 cursor-pointer"
                onClick={() => toggleExpand(country)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{flag}</span>
                    <div>
                      <h3 className="font-semibold text-slate-100">{country}</h3>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-xs text-slate-500">{reg}</span>
                        <span className="text-slate-600">·</span>
                        <span className="text-xs text-slate-500">{cities.length} destination{cities.length !== 1 ? 's' : ''}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2 py-0.5 rounded-full hidden sm:block">
                      🌤 {bestSeason}
                    </span>
                    {isExpanded ? <ChevronDown size={16} className="text-slate-400" /> : <ChevronRight size={16} className="text-slate-400" />}
                  </div>
                </div>
              </div>

              {isExpanded && (
                <div className="border-t border-white/5 p-3 space-y-2 animate-fade-in">
                  {cities.map(city => {
                    const inTrip = tripCities.some(c => c.iata === city.iata);
                    const nights = nightCounts[city.iata] || 3;
                    const slug = city.city.toLowerCase().replace(/\s+/g, '-');
                    return (
                      <div key={city.iata} className={`flex items-center gap-3 p-3 rounded-xl transition-all ${inTrip ? 'bg-green-500/5 border border-green-500/20' : 'bg-surface border border-white/5'}`}>
                        <span className="text-xl">{city.emoji}</span>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-sm text-slate-200 truncate">{city.city}</div>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-xs text-indigo-400">{city.tag}</span>
                            <span className="text-slate-600">·</span>
                            <span className="text-xs text-slate-500">{city.iata}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 flex-shrink-0">
                          <button onClick={() => adjustNights(city.iata, -1)} className="w-6 h-6 rounded bg-card border border-white/10 flex items-center justify-center text-xs hover:bg-white/10">−</button>
                          <span className="text-xs text-slate-300 w-8 text-center">{nights}n</span>
                          <button onClick={() => adjustNights(city.iata, 1)} className="w-6 h-6 rounded bg-card border border-white/10 flex items-center justify-center text-xs hover:bg-white/10">+</button>
                          <Link to={`/city/${slug}`} className="p-1.5 rounded-lg bg-surface hover:bg-white/10 text-slate-400 hover:text-slate-200 transition-colors ml-1">
                            <Globe size={13} />
                          </Link>
                          <button onClick={() => handleAddCity(city)} className={`p-1.5 rounded-lg transition-colors ${inTrip ? 'bg-green-500/20 text-green-400' : 'bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400'}`}>
                            {inTrip ? <Check size={13} /> : <Plus size={13} />}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16">
          <Globe size={48} className="text-slate-600 mx-auto mb-3" />
          <h3 className="font-semibold text-slate-300 mb-1">No countries found</h3>
          <p className="text-slate-500 text-sm">Try adjusting your search or region filter</p>
        </div>
      )}
    </div>
  );
}
