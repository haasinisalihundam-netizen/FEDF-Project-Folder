import React, { useState, useRef } from 'react';
import { useTripContext } from '../context/TripContext';
import { getTransportRoute } from '../data/transport';
import { getVisaInfo } from '../data/visaRules';
import { getAttractions } from '../data/attractions';
import { getCurrency } from '../data/currencies';
import { Link } from 'react-router-dom';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Plane, Train, Bus, Car, Ship, ExternalLink, Info, DollarSign, Globe, Map, AlertCircle, ChevronDown, ChevronUp, Clock } from 'lucide-react';

ChartJS.register(ArcElement, Tooltip, Legend);

const TABS = ['Transport', 'Visa', 'Attractions', 'Budget', 'Currency'];
const BUDGET_TIERS = ['Budget', 'Mid-range', 'Luxury'];
const BUDGET_MULTIPLIERS = { Budget: 0.55, 'Mid-range': 1, Luxury: 2.2 };

const TRANSPORT_EMOJI = { Flight: '✈️', Train: '🚆', Bus: '🚌', Drive: '🚗', Ferry: '⛴️' };

const visaBadgeColors = {
  free: 'bg-green-500/20 text-green-400 border border-green-500/30',
  voa: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30',
  required: 'bg-red-500/20 text-red-400 border border-red-500/30',
  check: 'bg-slate-500/20 text-slate-400 border border-slate-500/30',
};

const GOOGLE_FLIGHTS_BASE = 'https://www.google.com/flights';

export default function Intelligence() {
  const { tripCities, nationality, currentItinerary, budgetTier, setBudgetTier } = useTripContext();
  const [activeTab, setActiveTab] = useState('Transport');

  if (tripCities.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 pt-24 pb-12 text-center animate-fade-in">
        <div className="text-6xl mb-4">🧠</div>
        <h2 className="text-xl font-bold text-slate-100 mb-2">No itinerary loaded</h2>
        <p className="text-slate-400 mb-6">Add cities in the planner first, then view Travel Intelligence here.</p>
        <Link to="/planner" className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-3 rounded-xl font-semibold transition-all">
          Go to Planner
        </Link>
      </div>
    );
  }

  const totalNights = tripCities.reduce((s, c) => s + (c.nights || 0), 0);
  const mult = BUDGET_MULTIPLIERS[budgetTier] || 1;

  const budgetBreakdown = {
    Transport: Math.round(Math.max(0, tripCities.length - 1) * 8500 * mult),
    Accommodation: Math.round(totalNights * 3500 * mult),
    Food: Math.round(totalNights * 1500 * mult),
    Activities: Math.round(totalNights * 1200 * mult),
  };
  const totalBudget = Object.values(budgetBreakdown).reduce((s, v) => s + v, 0);

  const chartData = {
    labels: Object.keys(budgetBreakdown),
    datasets: [{
      data: Object.values(budgetBreakdown),
      backgroundColor: ['#6366f1', '#22d3ee', '#4ade80', '#fbbf24'],
      borderColor: ['#07080f', '#07080f', '#07080f', '#07080f'],
      borderWidth: 2,
    }],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { position: 'bottom', labels: { color: '#94a3b8', padding: 16, font: { family: 'Cabinet Grotesk' } } },
      tooltip: { callbacks: { label: (ctx) => ` ₹${ctx.raw.toLocaleString()}` } },
    },
  };

  // Foreign cities for visa tab
  const foreignCities = tripCities.filter(c => {
    if (nationality === 'Indian') return c.country !== 'India';
    if (nationality === 'American') return c.country !== 'USA';
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 pt-24 pb-12 animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-100">Travel Intelligence</h1>
        <p className="text-slate-400 text-sm mt-1">Detailed information for your planned trip</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1.5 flex-wrap mb-6">
        {TABS.map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)} className={`pill-btn text-sm ${activeTab === tab ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-card text-slate-400 border-white/10 hover:text-slate-200'}`}>
            {tab}
          </button>
        ))}
      </div>

      <div className="animate-fade-in">
        {/* TRANSPORT TAB */}
        {activeTab === 'Transport' && (
          <div className="space-y-6">
            {tripCities.slice(0, -1).map((city, idx) => {
              const nextCity = tripCities[idx + 1];
              const route = getTransportRoute(city.iata, nextCity.iata);
              return (
                <div key={`${city.iata}-${nextCity.iata}`} className="bg-card border border-white/5 rounded-2xl overflow-hidden">
                  <div className="px-5 py-4 bg-indigo-600/5 border-b border-white/5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-xl">{city.emoji}</span>
                      <span className="font-semibold text-slate-100">{city.city}</span>
                      <span className="text-slate-500">→</span>
                      <span className="text-xl">{nextCity.emoji}</span>
                      <span className="font-semibold text-slate-100">{nextCity.city}</span>
                    </div>
                    <span className="text-xs text-slate-500">{city.iata} → {nextCity.iata}</span>
                  </div>
                  <div className="p-5 space-y-4">
                    {!route ? (
                      <div className="flex items-center gap-3">
                        <AlertCircle size={16} className="text-yellow-400" />
                        <span className="text-sm text-slate-400">No direct transport data available for this route.</span>
                        <a href={`${GOOGLE_FLIGHTS_BASE}?tfs=CBwQAhoeEgoyMDI1LTAxLTAxagcIARIDREVMcgcIARIDQUdS`} target="_blank" rel="noopener noreferrer" className="text-xs bg-indigo-600/20 text-indigo-400 hover:bg-indigo-600/30 px-3 py-1.5 rounded-lg transition-colors font-medium flex items-center gap-1">
                          Search Google Flights <ExternalLink size={11} />
                        </a>
                      </div>
                    ) : (
                      <>
                        {/* Flights */}
                        {route.flight && route.flight.length > 0 && (
                          <div>
                            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">✈️ Flights</h4>
                            <div className="space-y-2">
                              {route.flight.map((f, i) => (
                                <div key={i} className="flex items-center justify-between bg-surface rounded-xl px-4 py-3 flex-wrap gap-2">
                                  <div className="flex items-center gap-3">
                                    <span className="text-sm font-semibold text-slate-100">{f.airline}</span>
                                    <span className="text-xs text-slate-500 font-mono">{f.code}</span>
                                    <span className="text-xs text-slate-400 flex items-center gap-1"><Clock size={11} />{f.duration}</span>
                                  </div>
                                  <div className="flex items-center gap-3">
                                    <span className="text-sm text-green-400 font-semibold">₹{f.minPrice.toLocaleString()} – ₹{f.maxPrice.toLocaleString()}</span>
                                    <a href={f.link} target="_blank" rel="noopener noreferrer" className="text-xs bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1">
                                      Book <ExternalLink size={11} />
                                    </a>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        {/* Trains */}
                        {route.train && route.train.length > 0 && (
                          <div>
                            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">🚆 Trains</h4>
                            <div className="space-y-2">
                              {route.train.map((t, i) => (
                                <div key={i} className="bg-surface rounded-xl p-4">
                                  <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
                                    <div>
                                      <span className="font-semibold text-slate-100 text-sm">{t.name}</span>
                                      <span className="text-xs text-slate-500 ml-2 font-mono">{t.number}</span>
                                    </div>
                                    <div className="flex items-center gap-3">
                                      <span className="text-xs text-slate-400 flex items-center gap-1"><Clock size={11} />{t.duration}</span>
                                      <a href={t.link} target="_blank" rel="noopener noreferrer" className="text-xs bg-blue-600/80 hover:bg-blue-600 text-white px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1">
                                        IRCTC <ExternalLink size={11} />
                                      </a>
                                    </div>
                                  </div>
                                  {t.classes && (
                                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">
                                      {Object.entries(t.classes).map(([cls, info]) => (
                                        <div key={cls} className="bg-card rounded-lg p-2 text-center">
                                          <div className="text-xs font-bold text-indigo-400">{cls}</div>
                                          <div className="text-xs text-slate-200">₹{info.price}</div>
                                          <div className={`text-xs ${info.avail === 'Available' ? 'text-green-400' : info.avail === 'Moderate' ? 'text-yellow-400' : 'text-red-400'}`}>{info.avail}</div>
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        {/* Buses */}
                        {route.bus && route.bus.length > 0 && (
                          <div>
                            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">🚌 Bus</h4>
                            <div className="space-y-2">
                              {route.bus.map((b, i) => (
                                <div key={i} className="flex items-center justify-between bg-surface rounded-xl px-4 py-3 flex-wrap gap-2">
                                  <div className="flex items-center gap-3">
                                    <span className="text-sm font-semibold text-slate-100">{b.operator}</span>
                                    <span className="text-xs text-slate-400 flex items-center gap-1"><Clock size={11} />{b.duration}</span>
                                  </div>
                                  <div className="flex items-center gap-3">
                                    <span className="text-sm text-green-400 font-semibold">{b.price}</span>
                                    <a href={b.link} target="_blank" rel="noopener noreferrer" className="text-xs bg-orange-600/80 hover:bg-orange-600 text-white px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1">
                                      RedBus <ExternalLink size={11} />
                                    </a>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        {/* Drive */}
                        {route.drive && (
                          <div>
                            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">🚗 Drive</h4>
                            <div className="bg-surface rounded-xl px-4 py-3">
                              <div className="grid grid-cols-3 gap-4 text-center">
                                <div><div className="text-xs text-slate-500">Distance</div><div className="text-sm text-slate-200 font-medium">{route.drive.distance} km</div></div>
                                <div><div className="text-xs text-slate-500">Est. Fuel</div><div className="text-sm text-green-400 font-medium">₹{route.drive.fuelCost.toLocaleString()}</div></div>
                                <div><div className="text-xs text-slate-500">Est. Tolls</div><div className="text-sm text-yellow-400 font-medium">₹{route.drive.toll.toLocaleString()}</div></div>
                              </div>
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* VISA TAB */}
        {activeTab === 'Visa' && (
          <div className="space-y-4">
            <div className="bg-indigo-600/5 border border-indigo-500/20 rounded-xl px-4 py-3 text-sm text-slate-300 flex items-center gap-2">
              <Info size={16} className="text-indigo-400 flex-shrink-0" />
              Showing visa requirements for <strong className="text-indigo-400">{nationality}</strong> passport holders. Always verify with the official embassy before travel.
            </div>
            {foreignCities.length === 0 ? (
              <div className="bg-card border border-white/5 rounded-2xl p-8 text-center">
                <Globe size={48} className="text-slate-600 mx-auto mb-3" />
                <h3 className="font-semibold text-slate-300 mb-1">No foreign destinations</h3>
                <p className="text-sm text-slate-500">All your destinations are within your home country, or visa data is unavailable for the selected nationality.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {foreignCities.map((city, idx) => {
                  const visa = getVisaInfo(nationality, city.country);
                  const badgeClass = visaBadgeColors[visa.badge] || visaBadgeColors.check;
                  return (
                    <div key={city.iata} className="bg-card border border-white/5 rounded-2xl p-5">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{city.emoji}</span>
                          <div>
                            <h3 className="font-semibold text-slate-100">{city.city}</h3>
                            <p className="text-xs text-slate-400">{city.country}</p>
                          </div>
                        </div>
                        <span className={`text-xs px-2.5 py-1 rounded-full font-semibold ${badgeClass}`}>{visa.type}</span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 mb-3">
                        {[
                          { label: 'Fee', value: visa.fee },
                          { label: 'Processing', value: visa.processing },
                          { label: 'Validity', value: visa.validity },
                        ].map(({ label, value }) => (
                          <div key={label} className="bg-surface rounded-lg p-2">
                            <div className="text-xs text-slate-500">{label}</div>
                            <div className="text-xs text-slate-200 font-medium mt-0.5">{value}</div>
                          </div>
                        ))}
                      </div>
                      <div className="mb-3">
                        <div className="text-xs text-slate-500 mb-1.5">Required Documents</div>
                        <ul className="space-y-1">
                          {visa.documents.slice(0, 4).map((doc, i) => (
                            <li key={i} className="text-xs text-slate-300 flex items-start gap-1.5">
                              <span className="text-indigo-400 mt-0.5">•</span>{doc}
                            </li>
                          ))}
                          {visa.documents.length > 4 && <li className="text-xs text-slate-500">+{visa.documents.length - 4} more</li>}
                        </ul>
                      </div>
                      <div className="bg-indigo-600/5 border border-indigo-500/20 rounded-lg px-3 py-2 text-xs text-slate-300">
                        <span className="text-indigo-400 font-medium">Note: </span>{visa.note}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ATTRACTIONS TAB */}
        {activeTab === 'Attractions' && (
          <div className="space-y-8">
            {tripCities.map((city) => {
              const cityAttractions = getAttractions(city.city).slice(0, 6);
              return (
                <div key={city.iata}>
                  <h2 className="font-bold text-slate-100 mb-4 flex items-center gap-2">
                    <span>{city.emoji}</span> {city.city}
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {cityAttractions.map((attr, i) => (
                      <div key={i} className="bg-card border border-white/5 rounded-xl p-4">
                        <div className="flex items-start gap-2 mb-2">
                          <span className="text-2xl">{attr.emoji}</span>
                          <div>
                            <h4 className="font-medium text-slate-100 text-sm">{attr.name}</h4>
                            <span className="text-xs text-indigo-400">{attr.category}</span>
                          </div>
                        </div>
                        <p className="text-xs text-slate-400 mb-2 leading-relaxed line-clamp-2">{attr.description}</p>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-500">{attr.hours?.split(';')[0]}</span>
                          <span className="text-green-400">{attr.feeINR === 0 ? 'Free' : `₹${attr.feeINR.toLocaleString()}`}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* BUDGET TAB */}
        {activeTab === 'Budget' && (
          <div className="space-y-6">
            {/* Tier Selector */}
            <div className="flex gap-2">
              {BUDGET_TIERS.map(tier => (
                <button key={tier} onClick={() => setBudgetTier(tier)} className={`pill-btn ${budgetTier === tier ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-card text-slate-400 border-white/10 hover:text-slate-200'}`}>
                  {tier === 'Budget' ? '🎒' : tier === 'Mid-range' ? '🏨' : '✨'} {tier}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Chart */}
              <div className="bg-card border border-white/5 rounded-2xl p-5">
                <h3 className="font-bold text-slate-100 mb-4">Budget Distribution</h3>
                <div className="h-64 relative">
                  <Doughnut data={chartData} options={chartOptions} />
                </div>
                <div className="text-center mt-4">
                  <div className="text-2xl font-bold gradient-text">₹{totalBudget.toLocaleString()}</div>
                  <div className="text-xs text-slate-500 mt-1">Estimated total ({budgetTier})</div>
                </div>
              </div>

              {/* Breakdown */}
              <div className="space-y-3">
                {Object.entries(budgetBreakdown).map(([cat, val], i) => {
                  const colors = ['#6366f1', '#22d3ee', '#4ade80', '#fbbf24'];
                  const pct = Math.round((val / totalBudget) * 100);
                  return (
                    <div key={cat} className="bg-card border border-white/5 rounded-xl p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-slate-200">{cat}</span>
                        <div className="text-right">
                          <div className="text-sm font-bold" style={{ color: colors[i] }}>₹{val.toLocaleString()}</div>
                          <div className="text-xs text-slate-500">{pct}%</div>
                        </div>
                      </div>
                      <div className="w-full h-1.5 bg-surface rounded-full overflow-hidden">
                        <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, backgroundColor: colors[i] }} />
                      </div>
                    </div>
                  );
                })}
                <div className="bg-indigo-600/5 border border-indigo-500/20 rounded-xl p-4">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-slate-100">Total Estimate</span>
                    <span className="text-xl font-bold gradient-text">₹{totalBudget.toLocaleString()}</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-2">*These are estimates for {totalNights} nights with {tripCities.length} destinations. Actual costs will vary based on booking time, season, and personal preferences.</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* CURRENCY TAB */}
        {activeTab === 'Currency' && (
          <div className="space-y-4">
            <div className="bg-cyan-600/5 border border-cyan-500/20 rounded-xl px-4 py-3 text-sm text-slate-300 flex items-center gap-2">
              <Info size={16} className="text-cyan-400 flex-shrink-0" />
              Exchange rates are approximate and for reference only. Use Wise, Forex cards, or airport money changers for actual conversions.
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...new Map(tripCities.map(c => [c.country, c])).values()].map((city) => {
                const curr = getCurrency(city.country);
                return (
                  <div key={city.country} className="bg-card border border-white/5 rounded-2xl p-5">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{city.emoji}</span>
                        <div>
                          <h3 className="font-semibold text-slate-100 text-sm">{city.country}</h3>
                          <p className="text-xs text-slate-400">{curr.name}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-bold text-indigo-400">{curr.symbol}</div>
                        <div className="text-xs text-slate-500">{curr.code}</div>
                      </div>
                    </div>
                    <div className="bg-surface rounded-lg p-3 mb-3">
                      <div className="text-xs text-slate-500 mb-1">Exchange Rate</div>
                      <div className="text-sm text-slate-200">1 {curr.code} = <span className="text-green-400 font-semibold">₹{curr.rate.toFixed(2)}</span></div>
                      <div className="text-xs text-slate-500 mt-0.5">₹1 = {curr.symbol}{(1 / curr.rate).toFixed(4)} {curr.code}</div>
                    </div>
                    <div className="space-y-1.5">
                      <div className="text-xs text-slate-500 mb-1">Quick Conversions</div>
                      {[100, 500, 1000, 5000].map(amt => (
                        <div key={amt} className="flex justify-between text-xs">
                          <span className="text-slate-400">{curr.symbol}{amt}</span>
                          <span className="text-slate-200">≈ ₹{(amt * curr.rate).toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="bg-card border border-white/5 rounded-2xl p-5">
              <h3 className="font-bold text-slate-100 mb-3">💳 Currency Tips</h3>
              <ul className="space-y-2">
                {[
                  'Use Wise or Revolut for the best exchange rates with minimal fees when spending abroad.',
                  'ForexCard from India (Thomas Cook, BookMyForex, or HDFC/ICICI multicurrency) locks in rates before your trip.',
                  'Notify your Indian bank before travel to avoid card blocks on foreign transactions.',
                  'Always pay in local currency when given the choice — Dynamic Currency Conversion (DCC) charges 3-5% extra.',
                  'Keep some USD/EUR as backup — widely accepted in most tourist destinations.',
                  'ATMs in your destination country typically offer the best rates; use your bank\'s partner ATMs to minimize fees.',
                ].map((tip, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-slate-300">
                    <span className="text-cyan-400 mt-0.5 flex-shrink-0">→</span>
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
