import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { airports } from '../data/airports';
import { sampleTrips } from '../data/sampleTrips';
import { useTripContext } from '../context/TripContext';
import { Plus, ArrowRight, Compass, Map, FileText, Star, Globe, Users, Zap, Shield, Download, MessageSquare, BarChart2, BookOpen, Heart, Plane, Check } from 'lucide-react';


const regions = ['All', 'Asia', 'Europe', 'Americas', 'Middle East', 'Africa', 'Oceania'];

const stats = [
  { value: '200+', label: 'Destinations', emoji: '🌍' },
  { value: '50+', label: 'Countries', emoji: '🗺️' },
  { value: '12K+', label: 'Trips Planned', emoji: '✈️' },
  { value: '99%', label: 'Satisfaction', emoji: '⭐' },
];

const features = [
  { icon: Map, title: 'Interactive Maps', desc: 'Plot your route on a live map with animated polyline connections between cities.' },
  { icon: BarChart2, title: 'Budget Analytics', desc: 'Track expenses across transport, accommodation, food, and activities with visual charts.' },
  { icon: FileText, title: 'PDF Export', desc: 'Export your complete trip itinerary as a professionally formatted PDF.' },
  { icon: Globe, title: 'Country Explorer', desc: 'Discover 80+ destinations with detailed city guides, weather, and cultural insights.' },
  { icon: Compass, title: 'Smart Planning', desc: 'AI-powered connection validation, packing lists, and best travel month recommendations.' },
  { icon: Shield, title: 'Visa Intelligence', desc: 'Instant visa requirements for your nationality across all destination countries.' },
  { icon: MessageSquare, title: 'Community', desc: 'Join topic-based travel communities to share tips and plans with fellow travelers.' },
  { icon: Download, title: 'Offline Ready', desc: 'All your trip data stored locally — access your plans without an internet connection.' },
];

export default function Landing() {
  const [region, setRegion] = useState('All');
  const [nightCounts, setNightCounts] = useState({});
  const { addCity, tripCities, user } = useTripContext();
  const navigate = useNavigate();

  const filtered = region === 'All' ? airports : airports.filter(a => a.region === region);

  const handleAddToTrip = (airport) => {
    const nights = nightCounts[airport.iata] || 3;
    addCity({ ...airport, nights });
    navigate('/planner');
  };

  const handleSampleTrip = (trip) => {
    navigate('/planner');
  };

  const adjustNights = (iata, delta) => {
    setNightCounts(prev => ({
      ...prev,
      [iata]: Math.max(1, Math.min(30, (prev[iata] || 3) + delta)),
    }));
  };

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative pt-28 pb-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-900/20 via-transparent to-cyan-900/10" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-600/5 rounded-full blur-3xl" />

        <div className="relative max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-indigo-600/10 border border-indigo-600/20 text-indigo-400 text-sm px-4 py-2 rounded-full mb-6 font-medium">
            <Zap size={14} />
            <span>Your complete travel planning companion</span>
          </div>

          <h1 className="text-5xl sm:text-6xl md:text-7xl font-bold leading-tight mb-6">
            Plan your perfect
            <br />
            <span className="font-display gradient-text">journey</span>
            <br />
            <span className="text-slate-200">with TripFlow</span>
          </h1>

          <p className="text-lg text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed">
            From visa requirements to budget breakdowns, city guides to interactive maps —
            everything you need to plan an unforgettable trip, completely offline-capable.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3">
            {user ? (
              <>
                <Link to="/planner" className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-3 rounded-xl font-semibold transition-all glow-primary">
                  <Plane size={18} />
                  Start Planning
                </Link>
                <Link to="/explore" className="flex items-center gap-2 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-200 px-6 py-3 rounded-xl font-semibold transition-all">
                  <Compass size={18} />
                  Explore Destinations
                </Link>
              </>
            ) : (
              <>
                <Link to="/signup" className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-3 rounded-xl font-semibold transition-all glow-primary">
                  <Plane size={18} />
                  Start Planning
                </Link>
                <Link to="/login" className="flex items-center gap-2 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-200 px-6 py-3 rounded-xl font-semibold transition-all">
                  <Users size={18} />
                  Sign In
                </Link>
                <Link to="/explore" className="flex items-center gap-2 text-slate-400 hover:text-slate-200 px-4 py-3 rounded-xl font-semibold transition-all">
                  <Compass size={18} />
                  Try Sample
                </Link>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="px-4 pb-16">
        <div className="max-w-4xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((s) => (
            <div key={s.label} className="bg-card border border-white/5 rounded-2xl p-6 text-center card-hover">
              <div className="text-3xl mb-2">{s.emoji}</div>
              <div className="text-2xl font-bold gradient-text">{s.value}</div>
              <div className="text-sm text-slate-400 mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Sample Trips */}
      <section className="px-4 pb-16">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-slate-100 mb-2">Curated Itineraries</h2>
            <p className="text-slate-400">Get inspired with expertly crafted travel itineraries</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sampleTrips.map((trip) => (
              <div key={trip.id} className="bg-card border border-white/5 rounded-2xl p-5 card-hover">
                <div className="flex items-start justify-between mb-3">
                  <div className="text-3xl">{trip.emoji}</div>
                  <span className="text-xs bg-indigo-600/20 text-indigo-400 px-2 py-0.5 rounded-full font-medium">{trip.type}</span>
                </div>
                <h3 className="font-semibold text-slate-100 mb-2">{trip.title}</h3>
                <p className="text-xs text-slate-400 mb-3 leading-relaxed">{trip.description}</p>
                <div className="flex flex-wrap gap-1 mb-3">
                  {trip.cities.map(c => (
                    <span key={c} className="text-xs bg-surface border border-white/5 px-2 py-0.5 rounded-full text-slate-300">{c}</span>
                  ))}
                </div>
                <div className="flex items-center justify-between pt-3 border-t border-white/5">
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-slate-400">📅 {trip.days} days</span>
                    <span className="text-xs text-slate-400">₹{trip.estimatedBudget.toLocaleString()}</span>
                  </div>
                  <Link
                    to={user ? "/planner" : "/signup"}
                    className="text-xs bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400 px-3 py-1 rounded-lg transition-colors font-medium"
                  >
                    Use this
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Destinations Grid */}
      <section className="px-4 pb-16">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-slate-100 mb-2">Explore Destinations</h2>
            <p className="text-slate-400 mb-6">Browse 80+ destinations and add them to your trip</p>
            <div className="flex gap-2 flex-wrap">
              {regions.map(r => (
                <button
                  key={r}
                  onClick={() => setRegion(r)}
                  className={`pill-btn ${region === r ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white/5 text-slate-400 border-white/10 hover:text-slate-200 hover:bg-white/10'}`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filtered.slice(0, 40).map((airport) => {
              const inTrip = tripCities.some(c => c.iata === airport.iata);
              const nights = nightCounts[airport.iata] || 3;
              const slug = airport.city.toLowerCase().replace(/\s+/g, '-');
              return (
                <div
                  key={airport.iata}
                  className={`bg-card border rounded-2xl p-4 card-hover ${inTrip ? 'border-green-500/40 bg-green-500/5' : 'border-white/5'}`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="text-3xl">{airport.emoji}</div>
                    <div className="flex items-center gap-1">
                      {inTrip && <Check size={14} className="text-green-400" />}
                      <span className="text-xs text-yellow-400">★ {airport.rating}</span>
                    </div>
                  </div>
                  <h3 className="font-semibold text-slate-100">{airport.city}</h3>
                  <p className="text-xs text-slate-400 mb-1">{airport.country}</p>
                  <span className="text-xs bg-indigo-600/10 text-indigo-400 px-2 py-0.5 rounded-full mb-3 inline-block">{airport.tag}</span>
                  <p className="text-xs text-slate-500 mb-3 line-clamp-2 leading-relaxed">{airport.description}</p>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <button onClick={() => adjustNights(airport.iata, -1)} className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center text-xs hover:bg-white/20 transition-colors">−</button>
                      <span className="text-xs text-slate-300 w-12 text-center">{nights}n</span>
                      <button onClick={() => adjustNights(airport.iata, 1)} className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center text-xs hover:bg-white/20 transition-colors">+</button>
                    </div>
                    <div className="flex gap-1">
                      <Link to={`/city/${slug}`} className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors text-slate-400 hover:text-slate-200">
                        <BookOpen size={13} />
                      </Link>
                      <button
                        onClick={() => handleAddToTrip(airport)}
                        className={`p-1.5 rounded-lg transition-colors ${inTrip ? 'bg-green-500/20 text-green-400' : 'bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400'}`}
                      >
                        {inTrip ? <Check size={13} /> : <Plus size={13} />}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="text-center mt-8">
            <Link to="/explore" className="inline-flex items-center gap-2 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-300 px-6 py-3 rounded-xl font-semibold transition-all">
              View all destinations <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="px-4 pb-16">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-slate-100 mb-2">Everything you need</h2>
            <p className="text-slate-400">Comprehensive tools for every stage of your journey</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {features.map((f) => (
              <div key={f.title} className="bg-card border border-white/5 rounded-2xl p-5 card-hover">
                <div className="w-10 h-10 rounded-xl bg-indigo-600/20 flex items-center justify-center mb-3">
                  <f.icon size={20} className="text-indigo-400" />
                </div>
                <h3 className="font-semibold text-slate-100 mb-1.5">{f.title}</h3>
                <p className="text-sm text-slate-400 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      {!user && (
        <section className="px-4 pb-20">
          <div className="max-w-3xl mx-auto bg-gradient-to-br from-indigo-900/30 to-cyan-900/20 border border-indigo-500/20 rounded-3xl p-10 text-center">
            <h2 className="text-3xl font-bold text-slate-100 mb-4">
              Ready to plan your next adventure?
            </h2>
            <p className="text-slate-400 mb-8">Join thousands of travelers using TripFlow to plan smarter trips.</p>
            <div className="flex items-center justify-center gap-3 flex-wrap">
              <Link to="/signup" className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-3 rounded-xl font-semibold transition-all glow-primary">
                Get started free <ArrowRight size={16} />
              </Link>
              <Link to="/explore" className="flex items-center gap-2 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-200 px-6 py-3 rounded-xl font-semibold transition-all">
                Browse destinations
              </Link>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
