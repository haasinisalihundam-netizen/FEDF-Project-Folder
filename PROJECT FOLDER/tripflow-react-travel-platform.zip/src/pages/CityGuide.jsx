import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getByCitySlug } from '../data/airports';
import { getCityGuide } from '../data/cityGuides';
import { getAttractions } from '../data/attractions';
import { getLocalTransport, getArrivalTransport } from '../data/transport';
import { getWeather } from '../data/weatherData';
import { getCurrency } from '../data/currencies';
import { useTripContext } from '../context/TripContext';
import { Plus, Check, ArrowLeft, MapPin, Globe, Clock, Phone, Info, DollarSign, Utensils, Train, Star, Calendar, ShieldCheck, Package } from 'lucide-react';

const tabs = ['Overview', 'Budget', 'Attractions', 'Food', 'Transport', 'Festivals', 'Tips'];

const RainBadge = ({ level }) => {
  const colors = { Low: 'bg-green-500/20 text-green-400', Moderate: 'bg-yellow-500/20 text-yellow-400', High: 'bg-blue-500/20 text-blue-400' };
  return <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${colors[level] || colors.Low}`}>{level}</span>;
};

export default function CityGuide() {
  const { citySlug } = useParams();
  const navigate = useNavigate();
  const { addCity, tripCities } = useTripContext();

  const airport = getByCitySlug(citySlug);
  const guide = airport ? getCityGuide(airport.city) : null;
  const attractions = airport ? getAttractions(airport.city) : [];
  const localTransport = airport ? getLocalTransport(airport.city) : [];
  const arrivalTransport = airport ? getArrivalTransport(airport.city, airport.country) : [];
  const weather = airport ? getWeather(airport.city) : null;
  const currency = airport ? getCurrency(airport.country) : null;

  const [activeTab, setActiveTab] = useState('Overview');
  const inTrip = airport ? tripCities.some(c => c.iata === airport.iata) : false;

  if (!airport) {
    return (
      <div className="max-w-7xl mx-auto px-4 pt-28 pb-12 text-center">
        <div className="text-6xl mb-4">🗺️</div>
        <h2 className="text-xl font-bold text-slate-100 mb-2">City not found</h2>
        <p className="text-slate-400 mb-6">We couldn't find information for this destination.</p>
        <button onClick={() => navigate('/explore')} className="text-indigo-400 hover:text-indigo-300">← Back to Explore</button>
      </div>
    );
  }

  const handleAddToTrip = () => {
    addCity(airport);
    navigate('/planner');
  };

  // Generate generic guide data for cities without full guide
  const overview = guide || {
    description: airport.description + ' This destination offers a wonderful mix of culture, history, and unique local experiences that make it a worthwhile addition to any travel itinerary.',
    country: airport.country, region: airport.region, iata: airport.iata,
    currency: currency ? `${currency.name} (${currency.code})` : 'Local Currency',
    language: 'Local language; English in tourist areas', timezone: 'Local timezone',
    dialingCode: '+XX',
    budget: {
      budget: { accommodation: 'Budget options available', food: 'Street food and local restaurants', transport: 'Public transit', total: 'Approx ₹2,000–4,000/day' },
      midrange: { accommodation: 'Mid-range hotels', food: 'Restaurant dining', transport: 'Taxis and transit', total: 'Approx ₹5,000–10,000/day' },
      luxury: { accommodation: 'Luxury hotels', food: 'Fine dining', transport: 'Private transfers', total: 'Approx ₹15,000+/day' },
      costs: { metro: 'Varies', budgetMeal: 'Varies', midRestaurant: 'Varies', beer: 'Varies', coffee: 'Varies', hotel3star: 'Varies', airbnb: 'Varies' },
    },
    food: { dishes: [], areas: [] },
    festivals: [],
    tips: [
      'Research local customs before arrival', 'Keep copies of important documents',
      'Get travel insurance', 'Inform your bank of travel plans',
      'Download offline maps before arrival', 'Learn a few local phrases',
      'Try local cuisine at markets and street stalls', 'Respect local dress codes at religious sites',
    ],
    etiquette: 'Respect local customs and traditions.',
    safety: 'Exercise normal travel precautions.',
    emergency: { police: 'Local emergency number', ambulance: 'Local emergency number', touristHelpline: 'Check local tourism office' },
    visaNote: 'Check visa requirements before travel at the relevant embassy website.',
    packing: ['Passport', 'Travel insurance', 'Appropriate clothing', 'Sunscreen', 'Medications', 'Phone charger', 'Travel adapter', 'Cash'],
    highlights: [airport.tag + ' destination', 'Local culture and cuisine', 'Historical and natural attractions'],
  };

  return (
    <div className="max-w-7xl mx-auto px-4 pt-20 pb-12 animate-fade-in">
      {/* Header */}
      <div className="mb-6">
        <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-slate-400 hover:text-slate-200 transition-colors text-sm mb-4">
          <ArrowLeft size={16} /> Back
        </button>
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="text-5xl">{airport.emoji}</div>
            <div>
              <h1 className="text-3xl font-bold text-slate-100">{airport.city}</h1>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-slate-400 flex items-center gap-1"><MapPin size={13} />{airport.country}</span>
                <span className="text-slate-600">·</span>
                <span className="text-xs bg-indigo-600/20 text-indigo-400 px-2 py-0.5 rounded-full">{airport.tag}</span>
                <span className="text-xs text-yellow-400">★ {airport.rating}</span>
              </div>
            </div>
          </div>
          <button
            onClick={handleAddToTrip}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all flex-shrink-0 ${inTrip ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 'bg-indigo-600 hover:bg-indigo-500 text-white glow-primary'}`}
          >
            {inTrip ? <><Check size={16} /> Added to Trip</> : <><Plus size={16} /> Add to Trip</>}
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1.5 flex-wrap mb-6 border-b border-white/5 pb-4">
        {tabs.map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`pill-btn text-sm ${activeTab === tab ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-card text-slate-400 border-white/10 hover:text-slate-200'}`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="animate-fade-in">
        {activeTab === 'Overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-card border border-white/5 rounded-2xl p-6">
                <h2 className="font-bold text-slate-100 mb-3">About {airport.city}</h2>
                <p className="text-slate-300 leading-relaxed">{overview.description}</p>
              </div>
              {/* Weather */}
              {weather && (
                <div className="bg-card border border-white/5 rounded-2xl p-6">
                  <h3 className="font-bold text-slate-100 mb-2">Climate & Weather</h3>
                  <p className="text-sm text-slate-400 mb-4 leading-relaxed">{weather.summary}</p>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="text-slate-500 border-b border-white/5">
                          <th className="text-left py-2 pr-3 font-medium">Month</th>
                          {weather.monthly.map(m => <th key={m.month} className="px-2 py-2 font-medium text-center">{m.month}</th>)}
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b border-white/5">
                          <td className="py-2 pr-3 text-slate-400">Temp (°C)</td>
                          {weather.monthly.map(m => <td key={m.month} className="px-2 py-2 text-center text-slate-300">{m.temp}°</td>)}
                        </tr>
                        <tr>
                          <td className="py-2 pr-3 text-slate-400">Rain</td>
                          {weather.monthly.map(m => <td key={m.month} className="px-2 py-2 text-center"><RainBadge level={m.rain} /></td>)}
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div className="mt-3 flex items-center gap-2 flex-wrap">
                    <span className="text-xs text-slate-400">Best months:</span>
                    {weather.bestMonths.map(m => <span key={m} className="text-xs bg-green-500/10 text-green-400 border border-green-500/20 px-2 py-0.5 rounded-full">{m}</span>)}
                  </div>
                </div>
              )}
            </div>
            <div className="space-y-4">
              <div className="bg-card border border-white/5 rounded-2xl p-5">
                <h3 className="font-bold text-slate-100 mb-3 text-sm">Quick Info</h3>
                {[
                  { icon: Globe, label: 'Country', value: overview.country },
                  { icon: MapPin, label: 'Region', value: overview.region },
                  { icon: Info, label: 'IATA Code', value: overview.iata },
                  { icon: DollarSign, label: 'Currency', value: overview.currency },
                  { icon: Globe, label: 'Language', value: overview.language },
                  { icon: Clock, label: 'Time Zone', value: overview.timezone },
                  { icon: Phone, label: 'Dialing Code', value: overview.dialingCode },
                ].map(({ icon: Icon, label, value }) => (
                  <div key={label} className="flex gap-3 mb-3 last:mb-0">
                    <Icon size={14} className="text-indigo-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <div className="text-xs text-slate-500">{label}</div>
                      <div className="text-sm text-slate-200">{value}</div>
                    </div>
                  </div>
                ))}
              </div>
              {currency && (
                <div className="bg-card border border-white/5 rounded-2xl p-5">
                  <h3 className="font-bold text-slate-100 mb-3 text-sm">Currency</h3>
                  <div className="text-2xl font-bold text-indigo-400 mb-1">{currency.symbol}</div>
                  <div className="text-sm text-slate-300 mb-2">{currency.name}</div>
                  <div className="text-xs text-slate-400">1 {currency.code} = ₹{currency.rate.toFixed(2)}</div>
                  <div className="mt-3 space-y-1">
                    {[100, 500, 1000].map(amt => (
                      <div key={amt} className="flex justify-between text-xs">
                        <span className="text-slate-500">{currency.symbol}{amt}</span>
                        <span className="text-slate-300">≈ ₹{(amt * currency.rate).toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'Budget' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                { tier: 'Budget', data: overview.budget?.budget, color: 'green', emoji: '🎒' },
                { tier: 'Mid-range', data: overview.budget?.midrange, color: 'indigo', emoji: '🏨' },
                { tier: 'Luxury', data: overview.budget?.luxury, color: 'yellow', emoji: '✨' },
              ].map(({ tier, data, color, emoji }) => (
                <div key={tier} className={`bg-card border border-${color}-500/20 rounded-2xl p-5`}>
                  <div className="flex items-center gap-2 mb-4">
                    <span className="text-xl">{emoji}</span>
                    <h3 className="font-bold text-slate-100">{tier}</h3>
                  </div>
                  {data && Object.entries(data).map(([key, val]) => (
                    <div key={key} className="flex justify-between text-xs mb-2">
                      <span className="text-slate-400 capitalize">{key}</span>
                      <span className={`text-${color}-400 font-medium`}>{val}</span>
                    </div>
                  ))}
                </div>
              ))}
            </div>
            <div className="bg-card border border-white/5 rounded-2xl p-5">
              <h3 className="font-bold text-slate-100 mb-4">Average Costs</h3>
              {overview.budget?.costs && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {Object.entries(overview.budget.costs).map(([key, val]) => (
                    <div key={key} className="bg-surface rounded-xl p-3">
                      <div className="text-xs text-slate-500 mb-1 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</div>
                      <div className="text-sm font-semibold text-slate-200">{val}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'Attractions' && (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {attractions.map((attr, i) => (
                <div key={i} className="bg-card border border-white/5 rounded-2xl p-5">
                  <div className="flex items-start gap-3 mb-3">
                    <span className="text-3xl">{attr.emoji}</span>
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-100">{attr.name}</h3>
                      <span className="text-xs bg-indigo-600/10 text-indigo-400 px-2 py-0.5 rounded-full">{attr.category}</span>
                    </div>
                  </div>
                  <p className="text-sm text-slate-400 mb-4 leading-relaxed">{attr.description}</p>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="flex items-start gap-1.5">
                      <Clock size={12} className="text-slate-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <div className="text-slate-500">Hours</div>
                        <div className="text-slate-300">{attr.hours}</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <DollarSign size={12} className="text-slate-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <div className="text-slate-500">Entry Fee</div>
                        <div className="text-slate-300">{attr.fee}</div>
                        {attr.feeINR > 0 && <div className="text-indigo-400">≈ ₹{attr.feeINR.toLocaleString()}</div>}
                      </div>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <Clock size={12} className="text-slate-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <div className="text-slate-500">Duration</div>
                        <div className="text-slate-300">{attr.duration}</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <Train size={12} className="text-slate-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <div className="text-slate-500">Transport</div>
                        <div className="text-slate-300">{attr.transport}</div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'Food' && (
          <div className="space-y-6">
            {(guide?.food?.dishes && guide.food.dishes.length > 0) ? (
              <>
                <div>
                  <h2 className="font-bold text-slate-100 mb-4">Must-Try Dishes</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {guide.food.dishes.map((dish, i) => (
                      <div key={i} className="bg-card border border-white/5 rounded-2xl p-5">
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-semibold text-slate-100">{dish.name}</h3>
                          <span className="text-xs text-green-400 bg-green-500/10 px-2 py-0.5 rounded-full ml-2 flex-shrink-0">{dish.cost}</span>
                        </div>
                        <p className="text-sm text-slate-400 mb-2 leading-relaxed">{dish.description}</p>
                        <div className="flex items-center gap-1.5 text-xs text-slate-500">
                          <MapPin size={11} />
                          <span>{dish.where}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                {guide.food.areas && guide.food.areas.length > 0 && (
                  <div className="bg-card border border-white/5 rounded-2xl p-5">
                    <h3 className="font-bold text-slate-100 mb-3">Recommended Dining Areas</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {guide.food.areas.map((area, i) => (
                        <div key={i} className="flex items-center gap-2 text-sm text-slate-300">
                          <Utensils size={14} className="text-indigo-400 flex-shrink-0" />
                          {area}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="bg-card border border-white/5 rounded-2xl p-8 text-center">
                <Utensils size={40} className="text-slate-600 mx-auto mb-3" />
                <h3 className="font-semibold text-slate-300 mb-1">Local Cuisine</h3>
                <p className="text-sm text-slate-500">{airport.city} is known for its local culinary traditions. Explore local markets and restaurants for authentic experiences.</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'Transport' && (
          <div className="space-y-6">
            {arrivalTransport.length > 0 && (
              <div>
                <h2 className="font-bold text-slate-100 mb-4">Getting to {airport.city}</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {arrivalTransport.map((route, i) => (
                    <div key={i} className="bg-card border border-white/5 rounded-2xl p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <span>{route.mode === 'flight' ? '✈️' : route.mode === 'train' ? '🚆' : '🚌'}</span>
                        <span className="text-sm font-medium text-slate-200">from {route.from}</span>
                      </div>
                      <div className="text-xs text-slate-400 mb-1">Duration: {route.duration}</div>
                      <div className="text-xs text-indigo-400 font-medium">{route.fare}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div>
              <h2 className="font-bold text-slate-100 mb-4">Local Transport</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {localTransport.length > 0 ? localTransport.map((t, i) => (
                  <div key={i} className="bg-card border border-white/5 rounded-2xl p-5">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-2xl">{t.icon}</span>
                      <div>
                        <h3 className="font-semibold text-slate-100 text-sm">{t.name}</h3>
                        <span className="text-xs text-indigo-400">{t.type}</span>
                      </div>
                    </div>
                    <div className="text-xs text-green-400 font-medium mb-1">{t.fare}</div>
                    <div className="text-xs text-slate-400">{t.coverage}</div>
                  </div>
                )) : (
                  <div className="bg-card border border-white/5 rounded-2xl p-5 col-span-2">
                    <p className="text-slate-400 text-sm">Taxis, rideshares (Grab/Uber where available), and local buses are typically available. Check local transport apps.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'Festivals' && (
          <div>
            {(guide?.festivals && guide.festivals.length > 0) ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {guide.festivals.map((f, i) => (
                  <div key={i} className="bg-card border border-white/5 rounded-2xl p-5">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-slate-100">{f.name}</h3>
                      <span className="text-xs bg-yellow-500/10 text-yellow-400 border border-yellow-500/20 px-2 py-0.5 rounded-full ml-2 flex-shrink-0">{f.months}</span>
                    </div>
                    <p className="text-sm text-slate-400 mb-3 leading-relaxed">{f.description}</p>
                    <div className="flex items-start gap-2 text-xs text-slate-500">
                      <Star size={11} className="mt-0.5 text-yellow-400 flex-shrink-0" />
                      <span>{f.significance}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-card border border-white/5 rounded-2xl p-8 text-center">
                <Calendar size={40} className="text-slate-600 mx-auto mb-3" />
                <h3 className="font-semibold text-slate-300 mb-1">Local Festivals</h3>
                <p className="text-sm text-slate-500">{airport.city} celebrates various local and national festivals throughout the year. Check local tourism boards for upcoming events.</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'Tips' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="bg-card border border-white/5 rounded-2xl p-5">
                <h3 className="font-bold text-slate-100 mb-3 flex items-center gap-2"><Info size={16} className="text-indigo-400" /> Travel Tips</h3>
                <ul className="space-y-2">
                  {overview.tips?.map((tip, i) => (
                    <li key={i} className="flex items-start gap-2.5 text-sm text-slate-300">
                      <span className="text-indigo-400 mt-0.5 flex-shrink-0">•</span>
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-card border border-white/5 rounded-2xl p-5">
                <h3 className="font-bold text-slate-100 mb-3 flex items-center gap-2"><Globe size={16} className="text-cyan-400" /> Cultural Etiquette</h3>
                <p className="text-sm text-slate-300 leading-relaxed">{overview.etiquette}</p>
              </div>
              <div className="bg-card border border-white/5 rounded-2xl p-5">
                <h3 className="font-bold text-slate-100 mb-3 flex items-center gap-2"><ShieldCheck size={16} className="text-yellow-400" /> Safety</h3>
                <p className="text-sm text-slate-300 leading-relaxed">{overview.safety}</p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="bg-card border border-red-500/10 rounded-2xl p-5">
                <h3 className="font-bold text-slate-100 mb-3 flex items-center gap-2"><Phone size={16} className="text-red-400" /> Emergency Contacts</h3>
                {overview.emergency && Object.entries(overview.emergency).map(([key, val]) => (
                  <div key={key} className="flex justify-between text-sm mb-2">
                    <span className="text-slate-400 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                    <span className="text-slate-200 font-mono">{val}</span>
                  </div>
                ))}
              </div>
              <div className="bg-card border border-white/5 rounded-2xl p-5">
                <h3 className="font-bold text-slate-100 mb-2 flex items-center gap-2"><Info size={16} className="text-green-400" /> Visa Note</h3>
                <p className="text-sm text-slate-300 leading-relaxed">{overview.visaNote}</p>
              </div>
              <div className="bg-card border border-white/5 rounded-2xl p-5">
                <h3 className="font-bold text-slate-100 mb-3 flex items-center gap-2"><Package size={16} className="text-yellow-400" /> Packing Suggestions</h3>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  {overview.packing?.map((item, i) => (
                    <li key={i} className="flex items-center gap-2 text-xs text-slate-300">
                      <span className="text-indigo-400">✓</span>{item}
                    </li>
                  ))}
                </ul>
              </div>
              {overview.highlights && (
                <div className="bg-card border border-white/5 rounded-2xl p-5">
                  <h3 className="font-bold text-slate-100 mb-3 flex items-center gap-2"><Star size={16} className="text-yellow-400" /> Cultural Highlights</h3>
                  <ul className="space-y-2">
                    {overview.highlights.map((h, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-slate-300">
                        <span className="text-yellow-400 mt-0.5">→</span>{h}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
