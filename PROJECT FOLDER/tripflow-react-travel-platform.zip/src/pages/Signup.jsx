import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTripContext } from '../context/TripContext';
import { Plane, Eye, EyeOff, AlertCircle, Check } from 'lucide-react';

export default function Signup() {
  const { register } = useTripContext();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirmPassword: '' });
  const [errors, setErrors] = useState({});
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Name is required';
    if (!form.email.includes('@')) e.email = 'Valid email required';
    if (form.password.length < 6) e.password = 'Password must be at least 6 characters';
    if (form.password !== form.confirmPassword) e.confirmPassword = 'Passwords do not match';
    return e;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    setLoading(true);
    await new Promise(r => setTimeout(r, 700));

    const users = JSON.parse(localStorage.getItem('tf_users') || '[]');
    const userData = { name: form.name.trim(), email: form.email, password: form.password };
    users.push(userData);
    localStorage.setItem('tf_users', JSON.stringify(users));

    register(userData);
    navigate('/dashboard');
    setLoading(false);
  };

  const Field = ({ name, label, type = 'text', placeholder }) => (
    <div>
      <label className="block text-sm font-medium text-slate-300 mb-2">{label}</label>
      {name === 'password' || name === 'confirmPassword' ? (
        <div className="relative">
          <input
            type={showPwd ? 'text' : 'password'}
            value={form[name]}
            onChange={e => setForm(f => ({ ...f, [name]: e.target.value }))}
            className={`w-full bg-surface border rounded-xl px-4 py-3 pr-11 text-slate-200 placeholder-slate-500 focus:outline-none transition-colors text-sm ${errors[name] ? 'border-red-500/50 focus:border-red-500' : 'border-white/10 focus:border-indigo-500'}`}
            placeholder={placeholder}
          />
          {name === 'password' && (
            <button type="button" onClick={() => setShowPwd(!showPwd)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500">
              {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          )}
        </div>
      ) : (
        <input
          type={type}
          value={form[name]}
          onChange={e => setForm(f => ({ ...f, [name]: e.target.value }))}
          className={`w-full bg-surface border rounded-xl px-4 py-3 text-slate-200 placeholder-slate-500 focus:outline-none transition-colors text-sm ${errors[name] ? 'border-red-500/50 focus:border-red-500' : 'border-white/10 focus:border-indigo-500'}`}
          placeholder={placeholder}
        />
      )}
      {errors[name] && <p className="text-xs text-red-400 mt-1">{errors[name]}</p>}
    </div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center px-4 pt-16 pb-8">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-indigo-600 flex items-center justify-center mx-auto mb-4 glow-primary">
            <Plane size={24} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold text-slate-100">Create your account</h1>
          <p className="text-slate-400 mt-1">Start planning your perfect trips today</p>
        </div>

        <div className="bg-card border border-white/5 rounded-2xl p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <Field name="name" label="Full name" placeholder="Your name" />
            <Field name="email" label="Email address" type="email" placeholder="you@example.com" />
            <Field name="password" label="Password" placeholder="At least 6 characters" />
            <Field name="confirmPassword" label="Confirm password" placeholder="Repeat your password" />

            <div className="flex items-start gap-2 pt-1">
              <div className="w-4 h-4 rounded bg-indigo-600/20 border border-indigo-600/30 mt-0.5 flex items-center justify-center">
                <Check size={10} className="text-indigo-400" />
              </div>
              <p className="text-xs text-slate-400">
                By creating an account, you agree to store your trip data locally on this device.
              </p>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white py-3 rounded-xl font-semibold transition-all glow-primary mt-2"
            >
              {loading ? 'Creating account...' : 'Create account'}
            </button>
          </form>

          <p className="text-center text-sm text-slate-400 mt-4">
            Already have an account?{' '}
            <Link to="/login" className="text-indigo-400 hover:text-indigo-300 font-medium">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
