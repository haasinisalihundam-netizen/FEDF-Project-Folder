import React, { useState } from 'react';
import { useTripContext } from '../context/TripContext';
import { Send, Users } from 'lucide-react';

const rooms = [
  {
    id: 'general', name: 'General Travel', emoji: '🌍', description: 'All things travel — tips, recommendations, and general discussion',
    members: 847,
    messages: [
      { id: 1, user: 'Marco T.', avatar: 'M', time: '2h ago', text: 'Just got back from my Southeast Asia trip. Bali was unreal — especially the sunrise at Mount Batur. Would highly recommend booking a guide for the trek!' },
      { id: 2, user: 'Priya S.', avatar: 'P', time: '1h ago', text: 'Has anyone recently done the Golden Triangle in India? Planning to go in December and wondering about crowd levels at the Taj Mahal at sunrise.' },
      { id: 3, user: 'James R.', avatar: 'J', time: '45m ago', text: 'The Taj at sunrise in December is magical — go as soon as the gates open at 6am. The light is perfect and crowds are much thinner than mid-morning.' },
    ],
  },
  {
    id: 'asia', name: 'Asia Travelers', emoji: '🏯', description: 'Southeast Asia, East Asia, South Asia — all covered here',
    members: 623,
    messages: [
      { id: 1, user: 'Aiko N.', avatar: 'A', time: '3h ago', text: 'The cherry blossoms in Kyoto this year were extraordinary — peaked around March 29th along the Philosopher\'s Path. If you\'re going next year, book accommodation 6+ months ahead!' },
      { id: 2, user: 'Raj P.', avatar: 'R', time: '2h ago', text: 'First time in Thailand. Should I do Bangkok first then Phuket, or the other way around? I have 12 days total.' },
      { id: 3, user: 'Sarah L.', avatar: 'S', time: '1.5h ago', text: 'I\'d do Bangkok first to acclimate — 3 nights exploring temples, markets and street food. Then fly to Phuket for the remainder. Domestic flights are very affordable (less than ₹3,000 if booked 2 weeks out).' },
    ],
  },
  {
    id: 'europe', name: 'Europe Explorer', emoji: '🗼', description: 'European travel planning, tips, and trip reports',
    members: 512,
    messages: [
      { id: 1, user: 'Elena V.', avatar: 'E', time: '4h ago', text: 'Planning Paris-Rome-Barcelona in 15 days. My biggest tip: buy a Schengen train pass for the Paris-Rome leg via Thello sleeper — saves a night of accommodation and the Italian countryside is gorgeous.' },
      { id: 2, user: 'Thomas B.', avatar: 'T', time: '3h ago', text: 'For Barcelona, the Sagrada Familia tickets MUST be booked 2-3 weeks in advance online. The wait without tickets can be 3+ hours and you might not get in at all in peak season.' },
      { id: 3, user: 'Meera K.', avatar: 'M', time: '2h ago', text: 'On the Schengen visa — apply at least 4 weeks before departure for the main destination. France visa covers all 27 Schengen countries including Italy and Spain.' },
    ],
  },
  {
    id: 'india', name: 'India Trips', emoji: '🇮🇳', description: 'India travel — from Himalayan adventures to southern temples',
    members: 934,
    messages: [
      { id: 1, user: 'Vikram A.', avatar: 'V', time: '2h ago', text: 'Varanasi was the most profound travel experience of my life. The Dev Deepawali festival in November — over a million diyas illuminating all 84 ghats — is something I will never forget. If you can, time your visit for this.' },
      { id: 2, user: 'Sunita R.', avatar: 'S', time: '1.5h ago', text: 'Any tips for Rajasthan in summer (May)? I know it\'s off-season but I only have that time available.' },
      { id: 3, user: 'Anuj M.', avatar: 'A', time: '1h ago', text: 'In Rajasthan in May you\'ll have almost empty forts and palaces (which is amazing for photos) but temperatures hit 47°C. Go out only 7-10am and 5-7pm. Book air-conditioned hotels. The light in the forts in the morning heat is actually quite extraordinary.' },
    ],
  },
  {
    id: 'budget', name: 'Budget Travelers', emoji: '💰', description: 'Traveling smart on a budget — hacks, deals, and affordable adventures',
    members: 445,
    messages: [
      { id: 1, user: 'Carlos M.', avatar: 'C', time: '5h ago', text: 'Just did 3 weeks in Southeast Asia for under ₹80,000 all in including flights from Delhi. The key: cook a few meals at hostels, use night buses between countries (saves accommodation), eat at local markets not tourist restaurants.' },
      { id: 2, user: 'Lisa T.', avatar: 'L', time: '4h ago', text: 'For Japan on a budget — convenience store meals (7-Eleven, Lawson) are genuinely delicious and cost ₹300-600 for a full meal. JR Pass pays for itself if you\'re doing Tokyo-Kyoto-Osaka.' },
      { id: 3, user: 'Arjun P.', avatar: 'A', time: '3h ago', text: 'Hostelworld and Booking.com both give significant discounts for booking 30+ days in advance in Europe. Also — booking.com\'s "Genius" tier gives free room upgrades and late checkout once you reach tier 2.' },
    ],
  },
  {
    id: 'solo', name: 'Solo Adventures', emoji: '🎒', description: 'Solo travel tips, safety, meeting other travelers, and single adventures',
    members: 378,
    messages: [
      { id: 1, user: 'Deepa R.', avatar: 'D', time: '3h ago', text: 'Solo female travel in Japan is the absolute best. I felt safer walking alone at 1am in Shinjuku than in most cities I\'ve been to anywhere in the world. The country is just that safe.' },
      { id: 2, user: 'Alex H.', avatar: 'A', time: '2h ago', text: 'For solo travelers looking to meet people: hostel common rooms are great but also look for free walking tours in any major city (book through freetour.com) — you\'ll meet loads of interesting travelers.' },
      { id: 3, user: 'Nadia S.', avatar: 'N', time: '1h ago', text: 'My top solo travel apps: Meetup for local events, Couchsurfing for meetups (not just for accommodation — they have social events in most cities), and WorldPackers for short-term work exchanges if you want to stay longer somewhere.' },
    ],
  },
];

export default function Community() {
  const { user } = useTripContext();
  const [activeRoom, setActiveRoom] = useState(rooms[0]);
  const [roomMessages, setRoomMessages] = useState(() => {
    const init = {};
    rooms.forEach(r => { init[r.id] = [...r.messages]; });
    return init;
  });
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (!input.trim()) return;
    const msg = {
      id: Date.now(),
      user: user?.name || 'Traveler',
      avatar: (user?.name || 'T')[0].toUpperCase(),
      time: 'just now',
      text: input.trim(),
      isMe: true,
    };
    setRoomMessages(prev => ({ ...prev, [activeRoom.id]: [...(prev[activeRoom.id] || []), msg] }));
    setInput('');
  };

  const messages = roomMessages[activeRoom.id] || [];

  return (
    <div className="max-w-7xl mx-auto px-4 pt-20 pb-0 animate-fade-in">
      <div className="mb-4">
        <h1 className="text-2xl font-bold text-slate-100">Community</h1>
        <p className="text-slate-400 text-sm">Connect with fellow travelers and share your experiences</p>
      </div>
      <div className="flex flex-col md:flex-row gap-4 h-[calc(100vh-160px)]">
        {/* Room List */}
        <div className="md:w-72 flex-shrink-0">
          <div className="bg-card border border-white/5 rounded-2xl overflow-hidden h-full">
            <div className="p-4 border-b border-white/5">
              <h2 className="font-semibold text-slate-100 text-sm">Chat Rooms</h2>
            </div>
            <div className="overflow-y-auto">
              {rooms.map(room => (
                <button
                  key={room.id}
                  onClick={() => setActiveRoom(room)}
                  className={`w-full text-left px-4 py-3 border-b border-white/5 transition-all ${activeRoom.id === room.id ? 'bg-indigo-600/10 border-l-2 border-l-indigo-500' : 'hover:bg-white/5'}`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span>{room.emoji}</span>
                    <span className="font-medium text-sm text-slate-200">{room.name}</span>
                  </div>
                  <p className="text-xs text-slate-500 line-clamp-1">{room.description}</p>
                  <div className="flex items-center gap-1 mt-1 text-xs text-slate-600">
                    <Users size={10} />
                    <span>{room.members.toLocaleString()} members</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Chat Panel */}
        <div className="flex-1 flex flex-col bg-card border border-white/5 rounded-2xl overflow-hidden min-h-0">
          {/* Header */}
          <div className="px-5 py-4 border-b border-white/5 flex items-center gap-3 flex-shrink-0">
            <span className="text-2xl">{activeRoom.emoji}</span>
            <div>
              <h2 className="font-semibold text-slate-100">{activeRoom.name}</h2>
              <p className="text-xs text-slate-500">{activeRoom.description}</p>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4 scrollbar-hidden">
            {messages.map(msg => (
              <div key={msg.id} className={`flex gap-3 ${msg.isMe ? 'flex-row-reverse' : ''}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${msg.isMe ? 'bg-indigo-600' : 'bg-slate-600'}`}>
                  {msg.avatar}
                </div>
                <div className={`max-w-[80%] ${msg.isMe ? 'items-end' : 'items-start'} flex flex-col`}>
                  <div className={`flex items-center gap-2 mb-1 ${msg.isMe ? 'flex-row-reverse' : ''}`}>
                    <span className="text-xs font-medium text-slate-300">{msg.user}</span>
                    <span className="text-xs text-slate-600">{msg.time}</span>
                  </div>
                  <div className={`px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${msg.isMe ? 'bg-indigo-600 text-white rounded-tr-sm' : 'bg-surface text-slate-300 rounded-tl-sm'}`}>
                    {msg.text}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Input */}
          <div className="px-5 py-4 border-t border-white/5 flex gap-2 flex-shrink-0">
            <input
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleSend()}
              placeholder={`Message ${activeRoom.name}...`}
              className="flex-1 bg-surface border border-white/10 rounded-xl px-4 py-2.5 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim()}
              className="p-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl transition-all"
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
