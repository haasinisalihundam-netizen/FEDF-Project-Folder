import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useTripContext } from '../context/TripContext';
import { Heart, Trash2, Upload, Share2, Map, Calendar, Globe, FileText, Download } from 'lucide-react';

export default function Saved() {
  const { savedTrips, deleteSavedTrip, loadSavedTrip } = useTripContext();
  const [importUrl, setImportUrl] = useState('');
  const [importError, setImportError] = useState('');

  const handleShare = (trip) => {
    const encoded = btoa(JSON.stringify({ code: trip.code, name: trip.name, cities: trip.cities?.map(c => c.iata) }));
    const url = `${window.location.origin}/planner?trip=${encoded}`;
    navigator.clipboard?.writeText(url);
    alert('Share link copied!');
  };

  const handleImport = () => {
    setImportError('');
    try {
      const url = new URL(importUrl);
      const tripParam = url.searchParams.get('trip');
      if (!tripParam) throw new Error('No trip data in URL');
      const data = JSON.parse(atob(tripParam));
      alert(`Import: Trip "${data.name}" with ${data.cities?.length || 0} cities. Go to Planner to load.`);
    } catch {
      setImportError('Invalid trip URL. Please check the link and try again.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 pt-24 pb-12 animate-fade-in">
      <div className="flex items-center justify-between mb-8 flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">Saved Trips</h1>
          <p className="text-slate-400 text-sm mt-1">{savedTrips.length} trip{savedTrips.length !== 1 ? 's' : ''} saved</p>
        </div>
        <div className="flex gap-2 items-center">
          <input
            type="text"
            value={importUrl}
            onChange={e => setImportUrl(e.target.value)}
            placeholder="Paste trip share URL..."
            className="bg-card border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 w-64"
          />
          <button onClick={handleImport} disabled={!importUrl} className="flex items-center gap-2 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-300 px-4 py-2 rounded-xl text-sm font-medium transition-all disabled:opacity-50">
            <Download size={15} /> Import
          </button>
        </div>
      </div>

      {importError && <p className="text-red-400 text-sm mb-4">{importError}</p>}

      {savedTrips.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20">
          <Heart size={64} className="text-slate-700 mb-4" />
          <h2 className="text-xl font-semibold text-slate-300 mb-2">No saved trips yet</h2>
          <p className="text-slate-500 mb-6 text-center max-w-sm">
            Build a trip in the planner, generate an itinerary, and click Save to see it here.
          </p>
          <Link to="/planner" className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-3 rounded-xl font-semibold transition-all">
            Start Planning
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {savedTrips.map((trip) => (
            <div key={trip.id} className="bg-card border border-white/5 rounded-2xl p-5 hover:border-indigo-500/20 transition-all">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-slate-100 truncate">{trip.name || 'Unnamed Trip'}</h3>
                  <code className="text-xs text-indigo-400 font-mono">{trip.code}</code>
                </div>
                <button onClick={() => deleteSavedTrip(trip.id)} className="text-slate-600 hover:text-red-400 transition-colors p-1 ml-2">
                  <Trash2 size={15} />
                </button>
              </div>

              {/* Route string */}
              <div className="text-xs text-slate-400 mb-3 flex items-center gap-1 flex-wrap">
                {trip.cities?.map((c, i) => (
                  <React.Fragment key={c.iata}>
                    <span>{c.emoji} {c.city}</span>
                    {i < trip.cities.length - 1 && <span className="text-slate-600">→</span>}
                  </React.Fragment>
                ))}
              </div>

              {/* Meta */}
              <div className="flex items-center gap-3 text-xs text-slate-500 mb-4">
                <span><Calendar size={11} className="inline mr-1" />{trip.totalNights || 0} nights</span>
                <span><Globe size={11} className="inline mr-1" />{trip.cities?.length || 0} cities</span>
                {trip.nationality && <span>🌏 {trip.nationality}</span>}
              </div>

              {/* Traveler type + code */}
              <div className="flex items-center gap-2 mb-4">
                {trip.travelerType && (
                  <span className="text-xs bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2 py-0.5 rounded-full">{trip.travelerType}</span>
                )}
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                <button
                  onClick={() => loadSavedTrip(trip)}
                  className="flex-1 flex items-center justify-center gap-1.5 text-xs bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400 py-2 rounded-lg transition-colors font-medium"
                >
                  <Upload size={13} /> Load in Planner
                </button>
                <Link
                  to="/map"
                  onClick={() => loadSavedTrip(trip)}
                  className="flex items-center justify-center gap-1 text-xs bg-white/5 hover:bg-white/10 text-slate-400 px-3 py-2 rounded-lg transition-colors"
                >
                  <Map size={13} />
                </Link>
                <button
                  onClick={() => handleShare(trip)}
                  className="flex items-center justify-center gap-1 text-xs bg-white/5 hover:bg-white/10 text-slate-400 px-3 py-2 rounded-lg transition-colors"
                >
                  <Share2 size={13} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
