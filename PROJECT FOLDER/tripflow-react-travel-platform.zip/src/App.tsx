// @ts-nocheck
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { TripProvider } from './context/TripContext';
import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';
import Landing from './pages/Landing';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import Planner from './pages/Planner';
import Explore from './pages/Explore';
import CityGuide from './pages/CityGuide';
import MapView from './pages/MapView';
import Saved from './pages/Saved';
import Community from './pages/Community';
import Intelligence from './pages/Intelligence';

export default function App() {
  return (
    <Router>
      <TripProvider>
        <div className="min-h-screen bg-base text-slate-200">
          <Navbar />
          <main>
            <Routes>
              <Route path="/" element={<Landing />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/explore" element={<Explore />} />
              <Route path="/city/:citySlug" element={<CityGuide />} />
              <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
              <Route path="/planner" element={<ProtectedRoute><Planner /></ProtectedRoute>} />
              <Route path="/map" element={<ProtectedRoute><MapView /></ProtectedRoute>} />
              <Route path="/saved" element={<ProtectedRoute><Saved /></ProtectedRoute>} />
              <Route path="/community" element={<ProtectedRoute><Community /></ProtectedRoute>} />
              <Route path="/intelligence" element={<ProtectedRoute><Intelligence /></ProtectedRoute>} />
            </Routes>
          </main>
        </div>
      </TripProvider>
    </Router>
  );
}
